<?php

function unitTypesPdfVertical(){
	
	$unit_types = [];
	
	$property_details = acf_get_field('property_details');
	
	$unit_type = acf_get_sub_field( 'unit_type', $property_details );
	
	foreach( $unit_type['choices'] as $index =>  $ut){	
		
		$unit_types[$index] = [
			'ut' => $ut,
			'id' => convertToAbbreviationPdfVertical($ut),
			'title' => convertToFullNamePdfVertical($ut),
		
		];
	}
	
	return $unit_types;
}

function convertToAbbreviationPdfVertical($input) {
	// Remove spaces and slashes
	$cleaned = preg_replace('/\s+|\//', '', $input);
	
	// Convert to lowercase
	$lowercase = strtolower($cleaned);
	
	return $lowercase;
}

function convertToFullNamePdfVertical($input) {
	// Define regular expressions to match patterns like "1 Bdrm / 1 Bath" or "2 Bdrm / 2 Bath"
	//	$pattern = '/(\d+)\s*Bdrm\s*\/\s*(\d+)\s*Bath/i';
	$pattern = '/(\d+(\.\d+)?)\s*Bdrm\s*\/\s*(\d+(\.\d+)?)\s*Bath/i';

	// Use preg_replace_callback to replace matches using a callback function
	return preg_replace_callback($pattern, function($matches) {
		$bedrooms = intval($matches[1]);
		//$bathrooms = intval($matches[2]);
		$bathrooms = $matches[3];
		
		// Logic to convert to singular if necessary
		$bedroomText = $bedrooms == 1 ? 'Bedroom' : 'Bedrooms';
		$bathroomText = $bathrooms == 1 ? 'Bathroom' : 'Bathrooms';
		
		return "$bedrooms $bedroomText and $bathrooms $bathroomText";
	}, $input);
}

function postBackgroundVertical($pId)
{
    $imageMeta = wp_get_attachment_image_src(get_post_meta($pId, 'vertical_export_image', true), 'large');
    
    //spr($imageMeta); 
    $image = $imageMeta[0];
    $width = $imageMeta[1];
    $height = $imageMeta[2];
    $heading = postHeadingVertical($pId);
    $address = postAddressVertical($pId);
    $comments = postCommentsVertical($pId);
    
    if(!empty($comments)){
		$comments = '<h2 style="text-transform: uppercase; font-size: 22px;font-weight: bold; margin-top: 5%; margin-bottom: 5px; width:100%; float:left; color: #4d575f">COMMENTS:</h2>'.$comments;
	} 
    
    //pr($image); die;
    
    //<img src="'.$image.'" style="height: 450px; width:450px; border-radius: 20px; float:left; overflow: hidden; perspective: 1px;" />	
    
    //<div class="profile_img" style="background-image: url('.$image.'); position: absolute; width: 120px; height: 120px; border-radius: 120px;border-style: solid;  border-color: white; border-width: medium; overflow: hidden; background-size: 150px 150px;background-repeat: no-repeat; background-attachment: fixed; background-position: center; "></div> background-repeat: no-repeat; background-size:cover; background-position:center;
    
    // background-image-resize:6;
    
    return '
    <div style="100%;">
		<div style="width:50%; float:left;">'.$heading.' '.$address.' ' .$comments.'</div>
		<div style="width:45%; float:right; border-radius:20px; ">
			<div style="background-image: url('.$image.'); width:360px; height:280px; border-radius:20px; background-repeat: no-repeat; background-position: center; "></div>
		</div>
		
    </div>
    <br />';
}

function postCommentsVertical($pId)
{

    $comments = '';
    if (get_post_meta($pId, 'other_comments', true)) :
        $comments = '<p style="color: #4d4d4f; backgraound:red;">' . get_post_meta($pId, 'other_comments', true) . '</p>';
    endif;

    return $comments;
}

function postFees2($pId)
{
    return '<table style="width:100%;"> 
        <tbody>
            <tr>
                <td><strong>Deposit: </strong></td>
                <td>' . get_post_meta($pId, 'fees_deposit', true) . ' <span style="font-size:12px;">('.the_sub_field('fees_deposit_type'). ')</span></td>
            </tr>
            <tr>
                <td><strong>Admin Fee: </strong></td>
                <td>' . get_post_meta($pId, 'fees__admin_fee', true) . ' <span style="font-size:12px;">('.the_sub_field('fees_admin_fee_type'). ')</span></td>
            </tr>
            <tr>
                <td><strong>App Fee: </strong></td>
                <td>' . get_post_meta($pId, 'fees__app_fee', true) . ' <span style="font-size:12px;">('.the_sub_field('fees_app_fee_type'). ')</span></td>
            </tr>
            <tr>
                <td><strong>Pet Fee: </strong></td>
                <td>' . get_post_meta($pId, 'fees_pet_fee', true) . ' <span style="font-size:12px;">('.the_sub_field('fees_pet_fee_type'). ')</span></td>
            </tr>
            <tr>
                <td><strong>Pet Rent: </strong></td>
                <td>' . get_post_meta($pId, 'fees_pet_rent', true) . ' <span style="font-size:12px;">('.the_sub_field('fees_pet_rent_type'). ')</span></td>
            </tr>
            
        </tbody>
    </table>';
}

function postUtilitiesVertical($pId)
{
    return '<table style="width:100%;"> 
        <tbody>
            <tr>
                <td><strong>Water/Sewer: </strong></td>
                <td>' . get_post_meta($pId, 'utilities_watersewer', true) . '</td>
            </tr>
            <tr>
                <td><strong>Electricity: </strong></td>
                <td>' . get_post_meta($pId, 'utilities_electricity', true) . '</td>
            </tr>
            <tr>
                <td><strong>Gas: </strong></td>
                <td>' . get_post_meta($pId, 'utilities_gas', true) . '</td>
            </tr>
            <tr>
                <td><strong>Garbage: </strong></td>
                <td>' . get_post_meta($pId, 'utilities_garbage', true) . '</td>
            </tr>
            <tr>
                <td><strong>Concessions: </strong></td>
                <td>' . get_post_meta($pId, 'utilities_concessions', true) . '</td>
            </tr>
            
        </tbody>
    </table>';
}


function postAddressVertical($pId)
{
    return '<table style="width:100%;"><tbody>
        <tr><td style="color: #afc185; font-weight: bold; text-transform:uppercase; padding-top: 10px;">' . get_post_meta($pId, 'property_address', true) . '</td></tr>
        <tr><td style="color: #afc185; font-weight: bold; padding-bottom:15px;text-transform:uppercase;">' . get_post_meta($pId, 'property_city', true) . ', ' . get_post_meta($pId, 'property_state', true) . ' ' . get_post_meta($pId, 'property_zip', true) . '</td></tr>
        <tr style="margin-top: 10px;"><td style="color: #4d575f; padding:0px ;text-transform:uppercase; font-weight: bold;">TOTAL UNITS <span style="font-weight: normal;">' . get_post_meta($pId, 'number_of_units', true) . '</span></td></tr>
        <tr><td style="color: #4d575f;padding:0px ;text-transform:uppercase; font-weight: bold;">YEAR BUILT <span style=" font-family: Figtree, sans-serif; font-weight: normal;">' . get_post_meta($pId, 'year_built', true) . '</span></td></tr>
        <tr><td style="color: #4d575f; padding:0px ;text-transform:uppercase; font-weight: bold;">OCCUPANCY <span style=" font-family: Figtree, sans-serif; font-weight: normal;">' . get_post_meta($pId, 'occupancy', true) . '</span></td></tr>
    </tbody></table>';
}

function postHeadingVertical($pId)
{
    return '<h1 style="font-family: Figtree, sans-serif; color: #314328; text-transform: uppercase; font-size: 28px;font-weight: bold; margin-top: 0; margin-bottom: 5px;">
    ' . get_post_meta($pId, 'dealname', true) . '
</h1>';
}

function postUnitsVertical($pId)
{
    $propertyDetailsCount = get_post_meta($pId, 'property_details', true);
    $units = '<table style="width:100%; padding-top: 0px; font-size:13px; margin:0px; float: left; border-collapse: collapse; border:none;">
                <thead   style="border-collapse: collapse; border:none;">
                    <tr style="color: #4d4d4f;  border-collapse: collapse; border:none;">
                        <th style=" font-weight: bold; background-color: #afc185;  color: #FFF ;width: 25%; padding: 7px 0;">Unit Type</th>
                        <th style=" font-weight: bold; background-color: #afc185;  color: #FFF;width: 25%; padding: 7px 0;">Unit Sq. Ft.</th>
                        <th style=" font-weight: bold; background-color: #afc185;  color: #FFF;width: 25%; padding: 7px 0;">Asking Rent</th>
                        <th style=" font-weight: bold; background-color: #afc185;  color: #FFF;width: 25%; padding: 7px 0;">Asking Rent/SF</th>
                    </tr>
                </thead>
    <tbody style="border:none;">';
    $total_sf = 0;
    $total_rent = 0;
    $total_units = 0;
    for ($y = 0; $y < $propertyDetailsCount; $y++) {
		$no_of_units = get_post_meta($pId, 'property_details_' . $y . '_unit_count', true);
		$total_units = $total_units + $no_of_units;
        $unit_type = get_post_meta($pId, 'property_details_' . $y . '_unit_type', true);
        $sf = get_post_meta($pId, 'property_details_' . $y . '_unit_square_feet', true);
        $total_sf = $total_sf + ($sf * $no_of_units);
        $rent = get_post_meta($pId, 'property_details_' . $y . '_asking_rents', true);
        $total_rent = $total_rent + ($rent * $no_of_units);
        
        if ($rent && $sf) {
           $asking_rents_per_square_feet = ( ($rent * $no_of_units) / ($sf * $no_of_units ));
        }
        $rowColor =  ($y % 2 == 0)  ? '#FFF' : '#fff';
        $units .=
            '<tr style="text-align: center;">
                <td style=" color: #4d4d4f;text-align: center;background-color: ' . $rowColor . '; padding: 7px 0;">' . $unit_type . '</td>
                <td style=" color: #4d4d4f;text-align: center;background-color: ' . $rowColor . '; padding: 7px  0;">' . number_format($sf ) . '</td>
                <td style=" color: #4d4d4f;text-align: center;background-color: ' . $rowColor . '; padding: 7px  0;">$' . number_format($rent ). '</td>
                <td style=" color: #4d4d4f;text-align: center;background-color: ' . $rowColor . ';  padding: 7px 0;">$' . number_format(round($asking_rents_per_square_feet, 2), 2) . '</td>
            </tr>';
    }
    
    $sfPerUnits = $total_sf / $total_units;
	$rentPerUnits = $total_rent / $total_units;
	$rentPerSF = $total_rent / $total_sf;

    $units .=
        '<tr>
            <td style=" font-weight: bold; color: #FFFFFF; text-align: center; background: #304428; width: 25%; font-weight: bold; padding: 7px  0;">Totals/Averages</td>
            <td style=" font-weight: bold; color: #FFFFFF; text-align: center; background: #304428; width: 25%; font-weight: bold; padding: 7px  0;">' . ($total_units > 0 ?  number_format(round($sfPerUnits, 2), 0): 0). '</td>
            <td style=" font-weight: bold; color: #FFFFFF;text-align: center;  background: #304428; width: 25%; font-weight: bold; padding: 7px  0;">$' .($total_units > 0 ?  number_format(round($rentPerUnits, 2), 0): 0) . '</td>
            <td style=" font-weight: bold; color: #FFFFFF; text-align: center; background: #304428; width: 25%; font-weight: bold; padding: 7px  0;">$' . ($total_units > 0 ?  number_format(round($rentPerSF, 2), 2): 0) . '</td>
        </tr>
         </tbody></table>';

    return $units;
}


function postAmenitiesVertical($pId)
{
    $amenities = '';
    if (get_post_meta($pId, 'amenities', true)) {
		$as = get_post_meta($pId, 'amenities', true);
		
		if (($key = array_search("Other", $as)) !== false) {
			// Replace "Other" with "test"
			$custom_amenities = get_post_meta($pId, 'custom_amenities', true);
			$custom_amenities_array = preg_split('/[\r\n,]+/', $custom_amenities);
			$custom_amenities_array = array_map('trim', $custom_amenities_array);
			$as = array_merge(array_slice($as, 0, $key), $custom_amenities_array, array_slice($as, $key + 1));
			//~ $as = array_replace($as, [$key => get_post_meta($pId, 'custom_amenities', true)]);
		}
		
		//~ $amenityHtml = '<table style="width:100% "><tr><td style="width:10%" ></td><td style="width:40%" ><h3 style="font-family: Figtree, sans-serif; color: #314328; font-size: 18px; margin-left: 100px; margin-top: 0; margin-bottom: 5px;">Amenities:</h3></td><td style="width:40%" ></td></tr><tr>';
			//~ $index = 0;
			//~ foreach($as as $a){
				//~ if($index%2 == 0){
					//~ $amenityHtml .= '</tr><tr><td style="width:10%" ></td><td style="width:40%" >'.$a.'</td>';
				//~ } else {
					//~ $amenityHtml .= '<td style="width:40%">'.$a.'</td>';
				//~ }
				//~ $index ++;
			//~ } 
        
        //~ $amenityHtml .= '</tr></table>';
        
        $amenityHtml = '<table style="width:100%"><tr><td style="width:15%"></td><td style="width:42.5%"><h3 style="font-family: Figtree, sans-serif; color: #314328; font-size: 18px; margin-left: 100px; margin-top: 0; margin-bottom: 5px;">Amenities:</h3></td><td style="width:42.5%"></td></tr><tr>';
		$index = 0;
		$totalAs = count($as);
		$half = ceil($totalAs / 2);

		$first_column_records = array_slice($as, 0, $half); // Get the first 10 records
		$second_column_records = array_slice($as, $half); // Get the rest of the records
		
		$hasStar = false;

		foreach ($first_column_records as $index => $a) {
			
			$b = empty($second_column_records[$index]) ? '' : $second_column_records[$index];
			
			if (strpos($a, '*') !== false) {
				$hasStar = true;
			}
			
			if (strpos($b, '*') !== false) {
				$hasStar = true;
			}
			
			$amenityHtml .= '<td style="width:15%"></td>';
			$amenityHtml .= '<td style="width:42.5%">' .  $a   . '</td>';
			$amenityHtml .= '<td style="width:42.5%">' . $b  . '</td>';
			
			$amenityHtml .= '</tr><tr>';
		}

		$amenityHtml .= '</tr></table>';
        
        $amenities =  '<p style="color: #4d4d4f; width:100%; margin-top:30px; float:left;">' . $amenityHtml . '</p>';
        if($hasStar) {
			$amenities .=  '<p style="color: #4d4d4f; width:100%; margin-top:50px; float:left;"><table style="width:100%; margin-top:30px;"><tr><td style="width:15%"></td><td style="width:42.5%; color: #7d7d4f; text-align:left">*Select Units Only</td><td style="width:42.5%"></td></tr></table></p>';
		}
        
    }

    return $amenities;
}

//<!-- h2 style="font-family: figtree, sans-serif; font-weight: bold; width:100%; color: #314328; font-size: 30px; margin-left: 1%; margin-bottom: 0px; ">RENT COMPARABLES</h2 -->
function htmlPdfHeaderVertical()
{
    return '<!DOCTYPE html><html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    </head>
    <body style="font-family: Figtree, sans-serif; ">
    <div style="font-family: Figtree, sans-serif; width:100% ">';
}
function htmlPdfFooterVertical()
{
    return '</div></body></html>';
}
