<?php
if(TKC_DEBUG){
	error_reporting(E_ALL);
	ini_set('display_errors', true);
}

include(__DIR__ . '/export-horizontal-pdf-functions.php');

//~ error_reporting(E_ALL);
//~ ini_set('display_errors', '1');

function exportHorizontalPdfHTML($post_id, $x)
{
    $html = '';
    $pId = get_post_meta($post_id, 'rent_comps_' . $x . '_comp', true);


    $html .=
        '<div style="background-color: #FFF; margin:0 1% 0 1%; font-family: Figtree, sans-serif; width:48%; float:left">
                ' . postBackgroundHorizontal($pId) . '
                <table style="margin-top:20px; width: 100%;">
                    <tbody>
                        <tr>
                            <th style="text-align: left;   vertical-align: top; width: 40%; color: #4D5864; font-size: 14px; font-weight: 500; ">
                                <table style="width: 100%; margin-top: 20px;">
                                    <tbody>
                                        <tr>
                                            <td style="border-left: 1px solid #314328; padding-left: 20px; display: inline-block; width: 100%; "> 
                                            ' . postHeadingHorizontal($pId) . '
                                            ' . postAddressHorizontal($pId) . '
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </th>
                            <th style="width:60%; text-align: left;   vertical-align: top;">' . postUnitsHorizontal($pId) . '</th>
                        </tr>
                    </tbody>
                </table>                
            </div>';



    return $html;
}

function listingPdfHtmlHorizontal($post_id)
{
	
	$listingTypes = [
		'asking_rents' => 'AVERAGE RENT / MONTH',
		'asking_rentspsf_rounded' => 'AVERAGE RENT / SQUARE FOOT',
		'unit_square_feet' => 'AVERAGE SQUARE FEET',
	];
	
	$unitTypes = unitTypesPdfHorizontal();
	
	//pr($unitTypes); die;
	
	
	$html = '<div style="background-color: #FFF; margin: 0; font-family: Figtree, sans-serif; width:100%; text-align:center">';
	
	foreach($listingTypes as $tag => $subHeading) {
		foreach($unitTypes as $ut) {
			$html .= averageRentListCalculationHorizontal(strtoupper($ut['title'] . ' BY - '.$subHeading) , $post_id, $ut['ut'], $tag, $ut['id']);
		}
	}
	
	$html .= "</div>";
	
	
    //~ $html = '<div style="background-color: #FFF; margin: 0; font-family: Figtree, sans-serif; width:100%; text-align:center">';
    //~ $html .= averageRentListCalculation('ONE-BEDROOM SORTED BY - AVERAGE RENT / MONTH', $post_id, '1 Bdrm', 'asking_rents', 'bdrm1-avrge-moth');
    //~ $html .= averageRentListCalculation('TWO-BEDROOM SORTED BY - AVERAGE RENT / MONTH', $post_id, '2 Bdrm', 'asking_rents', 'bdrm2-avrge-moth');
    //~ $html .= averageRentListCalculation('THREE-BEDROOM SORTED BY - AVERAGE RENT / MONTH', $post_id, '3 Bdrm', 'asking_rents', 'bdrm3-avrge-moth');
    //~ $html .= averageRentListCalculation('ONE-BEDROOM SORTED BY - AVERAGE RENT / SQUARE FOOT', $post_id, '1 Bdrm', 'asking_rentspsf_rounded', 'bdrm1-avrge-sq');
    //~ $html .= averageRentListCalculation('TWO-BEDROOM SORTED BY - AVERAGE RENT / SQUARE FOOT', $post_id, '2 Bdrm', 'asking_rentspsf_rounded', 'bdrm2-avrge-sq');
    //~ $html .= averageRentListCalculation('THREE-BEDROOM SORTED BY - AVERAGE RENT / SQUARE FOOT', $post_id, '3 Bdrm', 'asking_rentspsf_rounded', 'bdrm3-avrge-sq');
    //~ $html .= averageRentListCalculation('ONE-BEDROOM SORTED BY - AVERAGE SQUARE FEET', $post_id, '1 Bdrm', 'unit_square_feet', 'bdrm1-avrge-feet');
    //~ $html .= averageRentListCalculation('TWO-BEDROOM SORTED BY - AVERAGE SQUARE FEET', $post_id, '2 Bdrm', 'unit_square_feet', 'bdrm2-avrge-feet');
    //~ $html .= averageRentListCalculation('THREE-BEDROOM SORTED BY - AVERAGE SQUARE FEET', $post_id, '3 Bdrm', 'unit_square_feet', 'bdrm3-avrge-feet');
    //~ $html .= "</div>";
    return $html;
}

function createTableHeaderHorizontal()
{
    return '<thead>
		<tr style="background: #AAC27E;color: #4d4d4f;border: none;text-align: center !important;text-transform: uppercase; letter-spacing: 1.5px;">
			<td scope="col" style="text-align: center;font-size: 18px; padding:7px; color: #fff; ">Apartment Community</td>
			<td scope="col" style="text-align: center;font-size: 18px; padding:7px; color: #fff; ">Year Built</td>
			<td scope="col" style="text-align: center;font-size: 18px; padding:7px; color: #fff; ">Number of Units</td>
			<td scope="col" style="text-align: center;font-size: 18px; padding:7px; color: #fff; ">Square Feet</td>
			<td scope="col" style="text-align: center;font-size: 18px; padding:7px; color: #fff;  ">Average Rent/Month</td>
			<td scope="col" style="text-align: center;font-size: 18px; padding:7px; color: #fff; ">Average Rent/ Square Foot</td>
		</tr>
	</thead>';
}

function averageRentListCalculationHorizontal($heading, $post_id, $Bdrm, $tag, $id_name)
{
    $html =
        '<div style="text-align:center; width:100%">
        <h1 style="text-align: center; color: #2C4425; font-size: 22px;font-weight: 400; margin-top: 25px; margin-bottom:0px;">' . $heading . '</h1>
        <table class="stats" style="margin: 0px;margin-top: 0px;margin-top: 0px;font-size:18px; width:100% ">
            ' . createTableHeaderHorizontal() . '
            <tbody>';
    $all_asking_rents_1b = [];
    $postCount = get_post_meta($post_id, 'rent_comps', true);
    $sum_unit_square_feet = $sum_asking_rents = $sum_asking_rentspsf_rounded = 0;
    for ($x = 0; $x < $postCount; $x++) {
        $pId = get_post_meta($post_id, 'rent_comps_' . $x . '_comp', true);
        $propertyDetailsCount = get_post_meta($pId, 'property_details', true);
        $class = '';
        $subjectPropertyId = get_post_meta($post_id, 'rent_comps_' . $x . '_subject_property', true);
        if ($subjectPropertyId) {
            $class = "background: #2f5a73 !important; color:#ffffff";
        };;;;
        for ($y = 0; $y < $propertyDetailsCount; $y++) {
            $unit_type = get_post_meta($pId, 'property_details_' . $y . '_unit_type', true);
            if (str_contains($unit_type, $Bdrm)) {
                $unit_square_feet = get_post_meta($pId, 'property_details_' . $y . '_unit_square_feet', true);
                $asking_rents = get_post_meta($pId, 'property_details_' . $y . '_asking_rents', true);
                $unit_count = get_post_meta($pId, 'property_details_' . $y . '_unit_count', true);
                $sum_unit_square_feet = $sum_unit_square_feet + $unit_square_feet;
                if ($asking_rents && $unit_square_feet) {
                    $asking_rents_per_square_feet = ($asking_rents / $unit_square_feet);
                    $asking_rentspsf_rounded = round($asking_rents_per_square_feet, 2);
                    $sum_asking_rents = $sum_asking_rents + $asking_rents;
                    $sum_asking_rentspsf_rounded = $sum_asking_rentspsf_rounded + $asking_rentspsf_rounded;
                    $all_asking_rents_1b[] =  array(
                        'dealname' =>  get_post_meta($pId, 'dealname', true),
                        'year_built' =>  get_post_meta($pId, 'year_built', true),
                        'number_of_units' =>  $unit_count,
                        'unit_square_feet' => number_format($unit_square_feet),
                        'asking_rents' => number_format($asking_rents),
                        'asking_rentspsf_rounded' => $asking_rentspsf_rounded,
                        'class' => $class
                    );
                }
            }
        }
    }
    $check_records = createListingHorizontal($all_asking_rents_1b, $tag, $id_name);
    if (empty($check_records)) {
        return '';
    } else {
        $html .= $check_records;
    }
    $html .= '</tbody>
        </table>
    </div>';
    return $html;
}

function createListingHorizontal($all_asking_rents, $sortField, $id)
{
    $response_data = '';
    $asking_rents_sort = array_column($all_asking_rents, $sortField);
    array_multisort($asking_rents_sort, SORT_DESC, $all_asking_rents);
    foreach ($all_asking_rents as $list) {
		//~ pr('unit_square_feet');
		//~ pr($list['unit_square_feet']);
		$usf = ( is_numeric($list['unit_square_feet']) ? number_format($list['unit_square_feet']) : $list['unit_square_feet']);
        $response_data .= '<tr ' . $list['class'] . '>
			<td style="text-align: center; font-size: 18px; ' . $list['class'] . '; padding:7px;">' . $list['dealname'] . '</td>
			<td style="text-align: center; font-size: 18px; ' . $list['class'] . '; padding:7px;">' . $list['year_built'] . '</td>
			<td style="text-align: center; font-size: 18px; ' . $list['class'] . '; padding:7px;">' . $list['number_of_units'] . '</td>
			<td style="text-align: center; font-size: 18px; ' . $list['class'] . '; padding:7px;">' . $usf . '</td>
			<td style="text-align: center; font-size: 18px; ' . $list['class'] . '; padding:7px;">$' . $list['asking_rents'] . '</td>
			<td style="text-align: center; font-size: 18px; ' . $list['class'] . '; padding:7px;">$' . $list['asking_rentspsf_rounded'] . '</td>
		</tr>';
    }
    //~ if ($response_data == '') {
        //~ $response_data = $id;
    //~ }
    return $response_data;
}


