<?php
require_once "../../../wp-load.php";

$dealsData = tkc_get_deals();

$deals = tkc_prepare_deals($dealsData);

tkc_create_post($deals);


//pr($deals);

$hubspot_all_deal_offset = get_tkc_option('hubspot_all_deal_offset');

echo  empty($hubspot_all_deal_offset) ? "All Deals Fetched"  : "Next Offset: " . $hubspot_all_deal_offset;

exit;
