<?php

require_once __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;



add_action('wp_ajax_tkc_download_xlsx', 'tkc_download_xlsx');
add_action('wp_ajax_nopriv_tkc_download_xlsx', 'tkc_download_xlsx');

if(TKC_DEBUG){
	error_reporting(E_ALL);
	ini_set('display_errors', true);
}

function unitTypes(){
	
	$unit_types = [];
	
	$property_details = acf_get_field('property_details');
	
	$unit_type = acf_get_sub_field( 'unit_type', $property_details );
	
	//~ echo "<pre>"; print_r($unit_type['choices']); echo "</pre>"; die;
	
	foreach( $unit_type['choices'] as $index =>  $ut){	
		
		$opt = explode("/", $index);
		
		$unit_types[$opt[0]] = [
			'ut' => $opt[0],
			'id' => convertToAbbreviation($ut),
			'title' => convertToFullname($ut),
		
		];
	}
	
	return $unit_types;
}

function convertToAbbreviation($input) {
	
	$opt = explode("/", $input);
	
	// Remove spaces and slashes
	$cleaned = preg_replace('/\s+|\//', '', $opt[0]);
	
	// Convert to lowercase
	$lowercase = strtolower($cleaned);
	
	return $lowercase;
}

function convertToFullname($input) {
	// Define regular expressions to match patterns like "1 Bdrm / 1 Bath" or "2 Bdrm / 2 Bath"
	//$pattern = '/(\d+)\s*Bdrm\s*\/\s*(\d+)\s*Bath/i';
	$pattern = '/(\d+(\.\d+)?)\s*Bdrm\s*\/\s*(\d+(\.\d+)?)\s*Bath/i';

	// Use preg_replace_callback to replace matches using a callback function
	return preg_replace_callback($pattern, function($matches) {
		$bedrooms = intval($matches[1]);
		//$bathrooms = intval($matches[2]);
		$bathrooms = $matches[3];
		
		// Logic to convert to singular if necessary
		$bedroomText = $bedrooms == 1 ? 'Bedroom' : 'Bedrooms';
		$bathroomText = $bathrooms == 1 ? 'Bathroom' : 'Bathrooms';
		
		return "$bedrooms $bedroomText";
		
		//~ return "$bedrooms $bedroomText and $bathrooms $bathroomText";
	}, $input);
}


function tkc_download_xlsx()
{
    $url =  empty($_REQUEST['url']) ? "https://tkcresources.wpengine.com/bens-rent-comps/" : $_REQUEST['url'];
    $post_id = url_to_postid($url);
    if ($post_id) {
        $post = get_post($post_id);
        $slug = $post->post_name;
    } else {
        $slug = time();
    }
    $file_name = $slug . "-" . time() . ".xlsx";
    $postCount = get_post_meta($post_id, 'rent_comps', true);


    $currentTime =  time();




    // Array of sheet names
    $sheetNames = ['General', 'Unit Mix', 'Fees & Utilities', 'Rent per Month', 'Rent per SF'];

    $sheets =  [
        [
            'name' => "General",
            'data' => generalSheetData($post_id),
        ],
        [
            'name' => "Unit Mix",
            'data' => unitMixSheetData($post_id),
        ],
        [
            'name' => "Fees & Utilities",
            'data' => feeAndUtilitiesSheetData($post_id),
        ],
        [
            'name' => "Rent per Month",
            'data' => rentPerMonthSheetData($post_id, "Rent / Month"),
        ],
        [
            'name' => "Rent per SF",
            'data' => rentPerMonthSheetData($post_id, "Rent / SF"),
        ]
    ];




    // Create sheets with data

    $xlsx_url =  generateSheet($post_id, $file_name, $sheets);


    echo json_encode([
        'status' => 'updated',
        'xlsx_url' => $xlsx_url,
        'post_id' => $post_id,
    ]);


    exit;
}

function generalSheetData($post_id)
{

    $all_asking_rents_1b = [];
    $properties = [
        'header' => [
            "Property",
            "Address",
            "Year Built",
            "Total No. of Units",
            "Average Square Feet",
            "Average Effective Rent",
            "Avg Effective Rent/SF"

        ]
    ];

    $property_count = 0;
    if (have_rows('rent_comps', $post_id)) {
        while (have_rows('rent_comps', $post_id)) {
            the_row();
            $post = get_sub_field('comp');

            if ($post) {

                $property['property'] =  $post->post_title;
                $address = [];

                $address[] = get_field('property_address', $post->ID);
                $address[] = get_field('property_city', $post->ID);
                $address[] = get_field('property_state', $post->ID);
                $address[] = get_field('property_zip', $post->ID);
                $address = array_filter($address, function ($value) {
					return $value !== null && strlen($value) > 0;
				});
				$property['address'] = implode(", ", $address);

                $property['year_built'] = get_field('year_built', $post->ID);
                $property['number_of_units'] = get_field('number_of_units', $post->ID);

                $total['unit_square_feet'] = 0;
                $total['asking_rents'] = 0;
                $total['asking_rentspsf_rounded'] = 0;
                $totalUnits = 0;

				$total_sf = 0;
				$total_rent = 0;
				$total_units = 0;


                if (have_rows('property_details', $post->ID)) {
                    while (have_rows('property_details', $post->ID)) {
                        the_row();

						$no_of_units = get_sub_field('unit_count', $post->ID);
						$total_units = $total_units + $no_of_units;
                        $unit_square_feet = get_sub_field('unit_square_feet', $post->ID);
                        $total_sf = $total_sf + ($unit_square_feet * $no_of_units);
                        $total['unit_square_feet'] += $unit_square_feet;
                        $asking_rents = get_sub_field('asking_rents', $post->ID);
                        $total_rent = $total_rent + ($asking_rents * $no_of_units);
                        $total['asking_rents'] += $asking_rents;

                        $asking_rents_per_square_feet = ($asking_rents / $unit_square_feet);
                        $asking_rentspsf_rounded = round($asking_rents_per_square_feet, 2);
                        $total['asking_rentspsf_rounded'] += $asking_rentspsf_rounded;

                        $totalUnits++;
                    }
                }
                
                $sfPerUnits = $total_sf / $total_units;
				$rentPerUnits = $total_rent / $total_units;
				$rentPerSF = $total_rent / $total_sf;

                $property['avg_unit_square_feet'] = ($totalUnits > 0 ? number_format(round($sfPerUnits, 0)) : 0);
                $property['avg_asking_rents'] = "$" . ($totalUnits > 0 ? number_format(round($rentPerUnits, 0)) : 0);
                $property['avg_asking_rentspsf_rounded'] = "$" . ($totalUnits > 0 ?  number_format($rentPerSF, 2) : 0);

                $properties['property_' . $property_count] = $property;
                $property_count++;
            }
        };
    };
    return $properties;
}


function unitMixSheetData($post_id)
{

    $properties = [
		$properties['header_top'] = [
			"",
            "",
            "",
            "",
            "",
            "",
            "",
            "Weighted Average",
            "",
            "",
		],
        'header' => [
            "Property Name",
            "Unit Type",
            "No of Units",
            "Unit Sq. Ft.",
            "Net Rent",
            "Net Rent/SF",
            "",
            "SF",
            "Net Rent",
            "Net Rent/SF",
       ],
    ];
    $property_count = 0;
    if (have_rows('rent_comps', $post_id)) {
        while (have_rows('rent_comps', $post_id)) {
            the_row();
            $post = get_sub_field('comp');

            if ($post) {

                //pr($post);
                //pr($post->ID);
                $total = [
                    "net_rent" => 0,
                    "unit_square_feet" => 0,
                    "net_rent_per_sf" => 0,
                    "no_of_units" => 0,
                    "weighted_sf" => 0,
                    "weighted_net_rent" => 0,
                    "weighted_net_rent_per_sf" => 0,
                ];

                $unit_count = 0;
                if (have_rows('property_details', $post->ID)) {
                    while (have_rows('property_details', $post->ID)) {

                        //pr(the_row());
                        the_row();
                        //pr(get_sub_field('unit_type'));

                        $property['property_name'] =  $post->post_title;
                        $property['unit_type'] =  get_sub_field('unit_type');
                        $no_of_units = get_sub_field('unit_count');
                        $property['no_of_units'] =  $no_of_units;
                        
                        $unit_square_feet = get_sub_field('unit_square_feet');
                        $property['unit_square_feet'] = number_format($unit_square_feet);
                        $asking_rents = get_sub_field('asking_rents');
                        $property['net_rent'] =   "$" . number_format($asking_rents);
                        
                        $net_rent_per_sf = "NA";
                        if ($unit_square_feet > 0) {
                            $net_rent_per_sf = number_format(round($asking_rents / $unit_square_feet, 2), 2);
                        }
                        $property['net_rent_per_sf'] =   "$" .$net_rent_per_sf." ";
                        
                        
                        $property['first_space'] = "";
                        
                        $weighted_sf = $no_of_units * $unit_square_feet;
                        $property['weighted_sf'] = number_format($weighted_sf);
                        
                        $weighted_net_rent = $no_of_units * $asking_rents;
                        $property['weighted_net_rent'] = number_format($weighted_net_rent );
                        
                        
                        $weighted_net_rent_per_sf = 0;
                        
                        if ($weighted_sf > 0) {
                            $weighted_net_rent_per_sf = number_format(round($weighted_net_rent / $weighted_sf, 2), 2);
                        }
                        $property['weighted_net_rent_per_sf'] = "$" .$weighted_net_rent_per_sf;

                        $total['net_rent'] += $asking_rents;
                        $total['unit_square_feet'] += $unit_square_feet;
                        $total['net_rent_per_sf'] += $net_rent_per_sf;
                        
                        
                        $total['no_of_units'] += $no_of_units;
                        $total['weighted_sf'] += $weighted_sf;
                        $total['weighted_net_rent'] += $weighted_net_rent;
                        $total['weighted_net_rent_per_sf'] += $weighted_net_rent_per_sf;
                        
                        



                        $unit_count++;
                        $properties['property_' . $property_count . "_" . $unit_count] = $property;
                    }
                }
                
                $avgSf = ($total['no_of_units'] > 0 ? round($total['weighted_sf'] / $total['no_of_units'], 0) : 0);
                //pr($avgSf);
                $netRent = ($total['no_of_units'] > 0 ? round($total['weighted_net_rent'] / $total['no_of_units'], 0): "0.00");
                //pr($netRent);
                $netRentPerSf = ((int)$avgSf > 0 ) ? number_format(((float)$netRent / (int)$avgSf), 2) : "0.00";


                $properties['header_' . $property_count] = [
                    "",
                    "",
                    "Averages",
                    //~ "",
                    //~ ($unit_count > 0 ? round($total['unit_square_feet'] / $unit_count, 2) : 0),
                    number_format($avgSf, 0),
                    //number_format(round($total['unit_square_feet'] / $unit_count)),
                    //~ "$" . ($unit_count > 0 ? round($total['net_rent'] / $unit_count, 2) : 0),
                    //"$" . number_format(round($total['net_rent'] / $unit_count)),
                    number_format($netRent, 0),
                    //"$" . ($unit_count > 0 ? number_format(round($total['net_rent_per_sf'] / $unit_count, 2), 2) : 0),
                    "$" . $netRentPerSf,
                    "",
                    //~ ($total['no_of_units'] > 0 ? number_format(round($total['weighted_sf'] / $total['no_of_units'], 2), 2) : 0),
                    //~ ($total['no_of_units'] > 0 ? number_format(round($total['weighted_net_rent'] / $total['no_of_units'], 2), 2) : 0),
                    //~ "",
                    number_format($avgSf, 0),
                    number_format($netRent, 0),
                    "$" . $netRentPerSf,
                ];
                //$properties['property_' . $property_count] = $property;
                $property_count++;
            }
        };
    };
    //pr($properties);
    
    
    return $properties;
}


function feeAndUtilitiesSheetData($post_id)
{


    $properties = [
        'header' => [
            "Fees & Utilities",
            "Water/Sewer",
            "Gas",
            "Garbage",
            "Electricity",
            "Concessions",
            "Deposit",
            "Admin Fee",
            "App Fee",
            "Pet Fee",
            "Pet Rent"
        ]
    ];
    $property_count = 0;
    if (have_rows('rent_comps', $post_id)) {
        while (have_rows('rent_comps', $post_id)) {
            the_row();
            $post = get_sub_field('comp');

            if ($post) {
                $property['property_name'] =  $post->post_title;

                if (have_rows('utilities', $post->ID)) {
                    while (have_rows('utilities', $post->ID)) {
                        the_row();

                        $property['watersewer'] =  get_sub_field('watersewer');
                        $property['gas'] =  get_sub_field('gas');
                        $property['garbage'] =  get_sub_field('garbage');
                        $property['electricity'] =  get_sub_field('electricity');
                        $property['concessions'] =  get_sub_field('concessions');
                    }
                }
                if (have_rows('fees', $post->ID)) {
                    while (have_rows('fees', $post->ID)) {
                        the_row();

                        $property['deposit'] =  get_sub_field('deposit'); // .' - ' . get_sub_field('deposit_type');
                        $property['_admin_fee'] =  get_sub_field('_admin_fee'); // .' - ' . get_sub_field('admin_fee_type');
                        $property['_app_fee'] =  get_sub_field('_app_fee'); // .' - ' . get_sub_field('app_fee_type');
                        $property['pet_fee'] =  get_sub_field('pet_fee'); // .' - ' . get_sub_field('pet_fee_type');
                        $property['pet_rent'] =  get_sub_field('pet_rent'); // .' - ' . get_sub_field('pet_rent_type');
                    }
                }


                $properties['property_' . $property_count] = $property;
                $property_count++;
            }
        };
    };
    return $properties;
}

function rentPerMonthSheetData($post_id, $sort_by = "Rent per Month")
{
	
	$unitTypes = unitTypes();
	
	
	$properties = [
        'top_header' => [],
        'header' => []
	];
	
	foreach($unitTypes as $ut){
		//$properties['top_header'][] = $ut['title']." Sorted by - Average ".$sort_by;
		$title = str_replace('TH', '', $ut['title']);
		$properties['top_header'][] = $title;
        for ($j = 0; $j < 5; $j++) {
            $properties['top_header'][] = "";
        }
        
        $properties['header'][] = "Apartment";
        $properties['header'][] = "Year Built";
        //$properties['header'][] = "No. of Units";
        $properties['header'][] = "Square Feet";
        $properties['header'][] = "Average Rent/Month";
        $properties['header'][] = "Average Rent/SF";
        $properties['header'][] = "";
        
	}
	
    $property_count = 0;
    
    $bedRoomProperies = [];
    
    if (have_rows('rent_comps', $post_id)) {
        while (have_rows('rent_comps', $post_id)) {
            the_row();
            $post = get_sub_field('comp');

            if ($post) {

               
                if (have_rows('property_details',  $post->ID)) {
                    while (have_rows('property_details',  $post->ID)) {
                        the_row();
                        $room_count = 1;
                        if (str_contains(get_sub_field('unit_type'), '1 Bdrm')) {
                            $room_count = 1;
                        }
                        if (str_contains(get_sub_field('unit_type'), '2 Bdrm')) {
                            $room_count = 2;
                        }
                        if (str_contains(get_sub_field('unit_type'), '3 Bdrm')) {
                            $room_count = 3;
                        }
                        
                        $totalNoOfUints = 0;
                        $totalNoOfUintsArr = [];

                        foreach($unitTypes as $ut){
                            if (str_contains(get_sub_field('unit_type'), $ut['ut'])){
								$asking_rents = get_sub_field('asking_rents');
								$unit_square_feet = get_sub_field('unit_square_feet');
								$bedRoomProperies[$ut['ut']][] = [ 
								'property_name' => str_replace("&amp;", "&",$post->post_title),
                                'year_built' =>  get_field('year_built', $post->ID),
                                //'no_of_units' =>  get_sub_field('unit_count'),                                
                                'unit_square_feet' =>  $unit_square_feet,                                
                                //~ 'avg_rent_per_month' => round($asking_rents / 12, 0),
                                'avg_rent_per_month' => $asking_rents,
                                'avg_rent_per_sf' => $unit_square_feet > 0 ? $asking_rents / $unit_square_feet : 0,
                                'space' =>  ""
                                ];
                                
                                $totalNoOfUints = $totalNoOfUints + (get_sub_field('unit_count') ? (int)get_sub_field('unit_count') : 0);
                            }
                        }
                        
                        
                    }
                    //okay
                    //~ $bedRoomProperies[$post->ID][] = [
                          //~ "space1"=>"",
                          //~ "space2"=>"Total",
                          //~ "space3"=>$totalNoOfUints,
                          //~ "space4"=>"",
                          //~ "space5"=>"",
                          //~ "space6"=>"",
                          //~ "space7"=> ""
                        //~ ];
                }


               // $properties['property_' . $property_count] = $property;
                $property_count++;
            }
        }
    }
    
    //~ echo "<pre>"; print_r($unitTypes); echo "</pre>"; 
    //~ echo "<pre>"; print_r($bedRoomProperies); echo "</pre>"; 
    
    //~ die;
    
    
    $sortedArray = [];
    $sort_key = ($sort_by == "Rent / Month") ? 'avg_rent_per_month' : 'avg_rent_per_sf';
    $maxCount = 0;
    foreach($bedRoomProperies as $bedRoomNo =>  $bedProperties){
		$maxCount = $maxCount < count($bedProperties) ? count($bedProperties) : $maxCount;
		$sortedArray[$bedRoomNo] = sort_array_by($bedProperties, $sort_key);
	}
	
	
	 //echo "<pre>"; print_r($maxCount); echo "</pre>"; 
	
	 //echo "<pre>"; print_r($sortedArray); echo "</pre>"; 
	
	 //die;
	
	for($row = 0; $row < $maxCount; $row++){
		$property = [];
		foreach($unitTypes as $ut){
				
				$property['property_name_' . $ut['id']] =  !isset($sortedArray[$ut['ut']][$row]) && empty($sortedArray[$ut['ut']][$row]) ? "" : $sortedArray[$ut['ut']][$row]['property_name'];
				$property['year_built_' . $ut['id']] =  !isset($sortedArray[$ut['ut']][$row]) && empty($sortedArray[$ut['ut']][$row]) ? "" : $sortedArray[$ut['ut']][$row]['year_built'];
				//$property['no_of_units_' . $ut['id']] =   !isset($sortedArray[$ut['ut']][$row]) && empty($sortedArray[$ut['ut']][$row]) ? "" : $sortedArray[$ut['ut']][$row]['no_of_units'];
				$property['unit_square_feet_' . $ut['id']] =  !isset($sortedArray[$ut['ut']][$row]) && empty($sortedArray[$ut['ut']][$row]) ? "" : number_format($sortedArray[$ut['ut']][$row]['unit_square_feet']);
				$property['avg_rent_per_month_' . $ut['id']] =  !isset($sortedArray[$ut['ut']][$row]) && empty($sortedArray[$ut['ut']][$row]) ? "" : "$" . number_format(round($sortedArray[$ut['ut']][$row]['avg_rent_per_month'], 0));
				$property['avg_rent_per_sf_' . $ut['id']] =  !isset($sortedArray[$ut['ut']][$row]) && empty($sortedArray[$ut['ut']][$row]) ? "" : "$" . number_format(round($sortedArray[$ut['ut']][$row]['avg_rent_per_sf'], 2), 2);
				$property['space_' . $ut['id']] =  "";
		}
		$properties['property_' . $row] = $property;
	}
	
    return $properties;
}

function sort_array_by($array, $key = 'avg_rent_per_month') {
	$avgRentPerMonth = array_column($array, $key);

	array_multisort($avgRentPerMonth, SORT_DESC, $array);
	
	return $array; 
}

function generateSheet($post_id, $file_name, $sheets)
{


    $xlsxBasePath = WP_CONTENT_DIR . "/upgrade/XLSX-files/$post_id/";

    if (!file_exists($xlsxBasePath)) {
        mkdir($xlsxBasePath, 0777, true);
    } else {
        array_map('unlink', array_filter((array) array_merge(glob("$xlsxBasePath*"))));
        //mkdir($xlsxBasePath, 0777, true);
    }

    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();

    foreach ($sheets as $index => $sheetData) {
        if ($index > 0) {
            $spreadsheet->createSheet();
        }
        $spreadsheet->setActiveSheetIndex($index); // Set the current sheet as active
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle($sheetData['name']); // Set sheet name

        // Set data into cells
        $rowIndex = 0;
        foreach ($sheetData['data'] as $rowName => $rowData) {
            $columnIndex = 0;
            foreach ($rowData as $columnName => $cellValue) {
                $sheet->setCellValueByColumnAndRow($columnIndex + 1, $rowIndex + 1, $cellValue);

                // Center align cell value
                $sheet->getStyleByColumnAndRow($columnIndex + 1, $rowIndex + 1)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

                if (strpos($rowName, "header") !== false) {
                    // Set bold font for header row
                    $sheet->getStyleByColumnAndRow($columnIndex + 1, $rowIndex + 1)->getFont()->setBold(true);
                }

                $columnIndex++;
            }
            $rowIndex++;
        }
        
        // Auto-size columns
		//foreach (range('A', $sheet->getHighestColumn()) as $column) {
			//$sheet->getColumnDimension($column)->setAutoSize(true);
		//}
		// Calculate column widths based on content
		foreach ($sheet->getRowIterator() as $row) {
			foreach ($row->getCellIterator() as $cell) {
				$columnIndex = $cell->getColumn();
				//~ $columnWidth = $sheet->getColumnDimension($columnIndex)->getWidth();
				//~ $calculatedWidth = $sheet->getColumnDimension($columnIndex)->getCalculatedWidth();
				//~ $contentWidth = $sheet->getColumnDimension($columnIndex)->getContentWidth();
				//~ $newWidth = max($calculatedWidth, $contentWidth);
				$sheet->getColumnDimension($columnIndex)->setAutoSize(true);
			}
		}
    }

    // Save Excel 2007 file
    $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    $writer->save($xlsxBasePath . $file_name);

    return  site_url() . "/wp-content/upgrade/XLSX-files/$post_id/" . $file_name;
}


