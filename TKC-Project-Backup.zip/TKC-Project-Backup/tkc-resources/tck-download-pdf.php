<?php
require_once __DIR__ . '/vendor/autoload.php';


add_action('wp_ajax_tkc_download_pdf_horizontal', 'tkc_download_pdf_horizontal');
add_action('wp_ajax_nopriv_tkc_download_pdf_horizontal', 'tkc_download_pdf_horizontal');

if(TKC_DEBUG){
	error_reporting(E_ALL);
	ini_set('display_errors', true);
}

function tkc_download_pdf_horizontal()
{
    $url =  empty($_REQUEST['url']) ? "http://localhost/tkcresources/bens-rent-comps/" : $_REQUEST['url'];
    $post_id = url_to_postid($url);
    if ($post_id) {
        $post = get_post($post_id);
        $slug = $post->post_name;
    } else {
        $slug = time();
    }
    $file_name = $slug .time(). ".pdf";
    $mpdf = new \Mpdf\Mpdf(['format' => [559, 250]]);

    include(__DIR__ . '/pdf-horizontal/export-horizontal-pdf.php');
    $postCount = get_post_meta($post_id, 'rent_comps', true);

    $fontUrl = 'https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;700;900&display=swap';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $fontUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $fontStyles = curl_exec($ch);
    curl_close($ch);

    // Extract and register font faces
    preg_match_all('/font-family:\s*\'(.*?)\';\s*font-weight:\s*(\d+);\s*font-style:\s*(\w+);/', $fontStyles, $matches, PREG_SET_ORDER);

    foreach ($matches as $match) {
        $fontName = str_replace(' ', '', $match[1]);
        $fontWeight = $match[2];
        $fontStyle = $match[3];

        // Register font faces with mPDF
        $mpdf->fontdata[$fontName] = [
            'R' => 'Montserrat-Regular.ttf', // Replace with the regular font file
            'B' => 'Montserrat-Bold.ttf',    // Replace with the bold font file
            'I' => 'Montserrat-Italic.ttf',  // Replace with the italic font file
            'BI' => 'Montserrat-BoldItalic.ttf', // Replace with the bold italic font file
        ];
    }

    // Set font family
    $mpdf->SetFont('Montserrat');


    // for ($x = 0; $x < $postCount; $x++) {
    //     $html = htmlPDFHeader();
    //     $html .= exportPdfHTML($post_id,$x);
    //     $html .= htmlPDFFooter();
    //     $mpdf->SetDisplayMode('fullpage');
    //     $mpdf->WriteHTML($html);
    //     //if($x+1 != $postCount){ 
    //     $mpdf->AddPage();
    //     //}
    //     if($x+1 == $postCount){ 
    //         $html1 = listingPdfHTML($post_id);    
    //         //echo $html1;    
    //         $mpdf->WriteHTML($html1);
    //     }
    //     $html = '';
    // }  
    
    $mpdf->SetHTMLHeader('<h2 style="font-family: figtree, sans-serif; font-weight: bold; width:100%; color: #314328; font-size: 30px; margin-left: 1%; margin-bottom: 10px; ">RENT COMPARABLES</h2>');

    for ($x = 0; $x < $postCount; $x += 2) { // Increment by 2 to handle two properties per page
        $html = htmlPdfHeaderHorizontal();

        // Generate HTML for two properties
        $html .= exportHorizontalPdfHtml($post_id, $x);

        //echo exportPdfHTML($post_id, $x);

        // Check if there's another property to display on the same page
        if ($x + 1 < $postCount) {
            $html .= exportHorizontalPdfHtml($post_id, $x + 1);
        }

        $html .= htmlPdfFooterHorizontal();

        //echo $html; die;

        $mpdf->SetDisplayMode('fullpage');
        $mpdf->WriteHTML($html);

        //~ if ($x + 2 < $postCount) {
            //~ $mpdf->AddPage();
        //~ }

        //~ if ($x + 1 == $postCount) {
            //~ $mpdf->AddPage();
            //~ $listing = listingPdfHTML($post_id);
            //~ $mpdf->WriteHTML($listing);
        //~ }
        if ($x + 1 < $postCount) {
			$mpdf->AddPage();
		}
    }
    ob_get_clean();
    $mpdf->Output(WP_CONTENT_DIR . "/upgrade/" . $file_name, \Mpdf\Output\Destination::FILE);
    echo json_encode([
        'status' => 'updated',
        'pdf_url' => site_url() . "/wp-content/upgrade/" . $file_name,
        'post_id' => $post_id,
    ]);
    exit;
}

add_action('wp_ajax_tkc_download_pdf_vertical', 'tkc_download_pdf_vertical');
add_action('wp_ajax_nopriv_tkc_download_pdf_vertical', 'tkc_download_pdf_vertical');

function tkc_download_pdf_vertical()
{
    $url =  empty($_REQUEST['url']) ? "http://localhost/tkcresources/bens-rent-comps/" : $_REQUEST['url'];
    $post_id = url_to_postid($url);
    if ($post_id) {
        $post = get_post($post_id);
        $slug = $post->post_name;
    } else {
        $slug = time();
    }
    $file_name = $slug .time(). ".pdf";
    $mpdf = new \Mpdf\Mpdf(['format' => [250, 309]]);

    include(__DIR__ . '/pdf-vertical/export-vertical-pdf.php');
    $postCount = get_post_meta($post_id, 'rent_comps', true);

    $fontUrl = 'https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;700;900&display=swap';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $fontUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $fontStyles = curl_exec($ch);
    curl_close($ch);

    // Extract and register font faces
    preg_match_all('/font-family:\s*\'(.*?)\';\s*font-weight:\s*(\d+);\s*font-style:\s*(\w+);/', $fontStyles, $matches, PREG_SET_ORDER);

    foreach ($matches as $match) {
        $fontName = str_replace(' ', '', $match[1]);
        $fontWeight = $match[2];
        $fontStyle = $match[3];

        // Register font faces with mPDF
        $mpdf->fontdata[$fontName] = [
            'R' => 'Montserrat-Regular.ttf', // Replace with the regular font file
            'B' => 'Montserrat-Bold.ttf',    // Replace with the bold font file
            'I' => 'Montserrat-Italic.ttf',  // Replace with the italic font file
            'BI' => 'Montserrat-BoldItalic.ttf', // Replace with the bold italic font file
        ];
    }

    // Set font family
    $mpdf->SetFont('Montserrat');

	//$mpdf->SetHTMLHeader('<h2 style="font-family: figtree, sans-serif; font-weight: bold; width:100%; color: #314328; font-size: 30px; margin-left: 1%; margin-bottom: 10px; ">RENT COMPARABLES</h2>');

    for ($x = 0; $x < $postCount; $x++) { // Increment by 2 to handle two properties per page
        $html = htmlPdfHeaderVertical();

        // Generate HTML for two properties
        $html .= exportVerticalPdfHtml($post_id, $x);
		
        $html .= htmlPdfFooterVertical();

        $mpdf->SetDisplayMode('fullpage');
        $mpdf->WriteHTML($html);

        
        if ($x + 1 < $postCount) {
			$mpdf->AddPage();
		}
    }
    ob_get_clean();
    $mpdf->Output(WP_CONTENT_DIR . "/upgrade/" . $file_name, \Mpdf\Output\Destination::FILE);
    echo json_encode([
        'status' => 'updated',
        'pdf_url' => site_url() . "/wp-content/upgrade/" . $file_name,
        'post_id' => $post_id,
    ]);
    exit;
}


add_action('wp_ajax_tkc_download_xml', 'tkc_download_xml');
add_action('wp_ajax_nopriv_tkc_download_xml', 'tkc_download_xml');

function tkc_download_xml()
{
    $url =  empty($_REQUEST['url']) ? "https://tkcresources.wpengine.com/bens-rent-comps/" : $_REQUEST['url'];
    $post_id = url_to_postid($url);
    if ($post_id) {
        $post = get_post($post_id);
        $slug = $post->post_name;
    } else {
        $slug = time();
    }
    $file_name = $slug . ".xml";
    $postCount = get_post_meta($post_id, 'rent_comps', true);
    $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Root></Root>');
    $imageBasePath = WP_CONTENT_DIR . "/XML-Images/$post_id/";
    $currentTime =  time();
    if (!file_exists($imageBasePath)) {
        mkdir($imageBasePath, 0777, true);
    } else {
        array_map('unlink', array_filter((array) array_merge(glob("$imageBasePath*"))));
        mkdir($imageBasePath, 0777, true);
    }

    for ($x = 0; $x < $postCount; $x++) {
        $entries = [];
        $pId = get_post_meta($post_id, 'rent_comps_' . $x . '_comp', true);
        $imageName = '';
        $subjectPropertyId = get_post_meta($pId, 'rent_comps_' . $x . '_subject_property', true);
        if (get_post_meta($pId, 'featured_image', true)) {
            $image = wp_get_attachment_image_src(get_post_meta($pId, 'featured_image', true), 'default');
            $pieces = explode('/', $image[0]);
            $image = end($pieces);
            $metaId = get_post_meta($pId, 'featured_image', true);
            $post = get_post($metaId);
            $guid = $post->guid;
            $imageName = $pId . '-' . $image;
            $localFilePath = $imageBasePath . $imageName;
            copy($guid, $localFilePath);
        } else {
            $image = 'No-Image';
        }
        $featuredImage = $xml->addChild('featured-image');
        $featuredImage->addAttribute('href', "file:///C:/XML-Images/$post_id/" . $imageName);

        $listing = $xml->addChild('table');
        $table = $listing->addChild('table');
        $table->addAttribute('frame', 'none');
        $tgroup = $table->addChild('tgroup');
        $tgroup->addAttribute('cols', '4');
        $colspecs = ['137.48000000000002pt', '81.39999999999998pt', '82.79999999999995pt', '80.64000000000004pt'];
        foreach ($colspecs as $colspec) {
            $colspecElement = $tgroup->addChild('colspec');
            $colspecElement->addAttribute('colname', 'c' . (array_search($colspec, $colspecs) + 1));
            $colspecElement->addAttribute('colwidth', $colspec);
        }
        $tbody = $tgroup->addChild('tbody');
        $entries[] = [
            0 => 'Unit Type',
            1 => 'Unit Sq. Ft.',
            2 => 'Asking Rent',
            3 => 'Asking Rent SF'
        ];
        $sum_unit_square_feet = $sum_asking_rents = $sum_asking_rentspsf_rounded = 0;
        $propertyDetailsCount = get_post_meta($pId, 'property_details', true);
        for ($y = 0; $y < $propertyDetailsCount; $y++) {
            $unit_type = get_post_meta($pId, 'property_details_' . $y . '_unit_type', true);
            $unit_square_feet = get_post_meta($pId, 'property_details_' . $y . '_unit_square_feet', true);
            $asking_rents = get_post_meta($pId, 'property_details_' . $y . '_asking_rents', true);

            $asking_rents_per_square_feet = ($asking_rents / $unit_square_feet);
            $asking_rentspsf_rounded = round($asking_rents_per_square_feet, 2);
            $sum_unit_square_feet = $sum_unit_square_feet + $unit_square_feet;
            $sum_asking_rents = $sum_asking_rents + $asking_rents;
            $sum_asking_rentspsf_rounded = $sum_asking_rentspsf_rounded + $asking_rentspsf_rounded;
            $entries[] =  [
                0 => $unit_type,
                1 => $unit_square_feet,
                2 => '$' . $asking_rents,
                3 => '$' . $asking_rentspsf_rounded
            ];
        }
        $entries[] =  [
            0 => 'Totals/Averages',
            1 => round($sum_unit_square_feet / $propertyDetailsCount),
            2 => '$' . ($sum_asking_rents / $propertyDetailsCount),
            3 => '$' . round($sum_asking_rentspsf_rounded / $propertyDetailsCount, 2)
        ];
        foreach ($entries as $key => $entry) {
            $row = $tbody->addChild('row');
            foreach ($entry as $value) {
                $entryElement = $row->addChild('entry', $value);
                $entryElement->addAttribute('colsep', '0');
                $entryElement->addAttribute('rowsep', '0');
                $entryElement->addAttribute('align', 'center');
                $entryElement->addAttribute('valign', 'middle');
            }
        }
        $xml->addChild('dealname', get_field('dealname', $pId));
        $xml->addChild('address', get_field('property_zip', $pId) . ' ' . get_field('property_address', $pId) . ' ' . get_field('property_city', $pId) . ' ' . get_field('property_state', $pId));
        $totalCounts = $xml->addChild('total-counts');
        $totalCounts->addChild('total-units', ' TOTAL UNITS ' . get_field('number_of_units', $pId));
        $totalCounts->addChild('year-build', ' YEAR BUILD ' . get_field('year_built', $pId));
        $totalCounts->addChild('occupancy', ' OCCUPANCY ' . get_field('occupancy', $pId));
    }
    $zip = new ZipArchive();

    $zipFileName = $imageBasePath . $currentTime . ".zip";
    fopen($zipFileName, "w");
    chmod($zipFileName, 0777);
    if ($zip->open($zipFileName, ZipArchive::OVERWRITE) === TRUE) {
        if ($handle = opendir($imageBasePath)) {
            while (false !== ($entry = readdir($handle))) {
                if ($entry != "." && $entry != "..") {
                    $zip->addFile($imageBasePath . $entry, $entry);
                }
            }
            closedir($handle);
        }
        $zip->close();
    }

    // Format the XML to be more human-readable
    $dom = dom_import_simplexml($xml)->ownerDocument;
    $dom->formatOutput = true;
    $formattedXml = $dom->saveXML();
    file_put_contents(WP_CONTENT_DIR . "/upgrade/" . $file_name, $formattedXml);
    echo json_encode([
        'status' => 'updated',
        'xml_url' => site_url() . "/wp-content/upgrade/" . $file_name,
        'zip_file' => site_url() . "/wp-content/XML-Images/$post_id/" . basename($zipFileName),
        'post_id' => $post_id,
    ]);
    // header("Content-Disposition: attachment; filename=\"" . basename($zipFileName) . "\"");
    // header("Content-Type: application/octet-stream");
    // header("Content-Length: " . filesize($zipFileName));
    // header("Connection: close");

    exit;
}

function arrayToXml($array, &$xmlParent)
{
    foreach ($array as $key => $value) {
        if (is_array($value)) {
            if (is_numeric($key)) {
                $key = 'row'; // Use a generic name for numeric keys
            }
            $xmlNode = $xmlParent->addChild($key);
            arrayToXml($value, $xmlNode);
        } else {
            $xmlParent->addChild($key, htmlspecialchars($value));
        }
    }
}
