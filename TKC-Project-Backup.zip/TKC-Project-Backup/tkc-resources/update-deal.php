<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "../../../wp-load.php";

$access_token = tkc_get_fersh_token();
if(isset($_GET['deal_id'])){
    $deal_id= $_GET['deal_id'];
} else {
    $deal_id=28222800176;
}
$base_url = "https://api.hubapi.com";
$endpoint = "/deals/v1/deal/$deal_id";
$deal = curl_request($base_url . $endpoint, $access_token);
if (isset($response['status']) && $response['status'] == 'error') {
    die($response['message']);
}
$deal_stages = [
    '7597106' => "Leads",
    'appointmentscheduled' => "Numbers",
    'qualifiedtobuy' => "Listing",
    'presentationscheduled' => "Under Contract (Listed)",
    'decisionmakerboughtin' => "Under Contract (Off-Market)",
    'closedwon' => "Closing",
    '51518753' => "Holding - BR",
];
$deals = [];
$dealCount = 0;
$deals['deal_id'] = empty($deal['dealId']) ? $deal['deal_id'] : $deal['dealId'];
$deals['property_id'] = empty($deal['portalId']) ? $deal['property_id'] :  $deal['portalId'];

foreach ($deal['properties'] as $name => $property) {
    switch ($name) {
        case "dealstage": {
                $deals['deal_stage'] = $deal_stages[$property['value']];
                $deals['deal_stage'] = $property['value'];
                break;
            }
        case "dealname": {
                $deals['deal_name'] = $property['value'];
                $deals['property_name'] = $property['value'];
                break;
            }
        case "property_state_dropdown": {
                $deals['property_state'] = $property['value'];

                break;
            }
        case "hs_object_id": {
                $deals['deal_id'] = $property['value'];

                break;
            }
        default: {
                $deals[$name] = $property['value'];
            }
    }
}

$acf_field_mapping = [
    'deal_id' => 'hs_object_id',
    'division' => 'division',
    'deal_name' => 'dealname',
    'deal_stage' => 'dealstage',
    'property_name' => 'property_name',
    'property_address' => 'property_address',
    'property_city' => 'property_city',
    'property_state' => 'property_state',
    'year_built' => 'year_built',
    'number_of_units' => 'number_of_units',
];
$stages =   ["Leads", "Numbers", "Listing", "Under Contract (Listed)", "Under Contract (Off-Market)"];
$stages = ['7597106', 'appointmentscheduled', 'qualifiedtobuy', 'presentationscheduled', 'decisionmakerboughtin'];
if (
    in_array($deals['deal_stage'], $stages)
    && !empty($deals['deal_name'])
    && !empty($deals['property_address'])
    && !empty($deals['property_city'])
    && !empty($deals['property_state'])
) {
    $post_id = tkc_get_post_id_by_meta_key_and_value('hs_object_id', $deals['deal_id']);
    if (!$post_id) {
        // Create a new post
        $post_id = wp_insert_post(array(
            'post_title' => $deals['deal_name'],
            'post_status' => 'publish',
            'post_type' => 'rentcomps', // Change this to your custom post type if necessary
        ));
    }
    foreach ($acf_field_mapping as $property_key => $acf_field_key) {
		
		if($property_key == 'deal_name'){
			// Update the post
			$post_data = array(
				'ID'         => $post_id,
				'post_title' => $deals['deal_name'],
			);

			// Update the post title
			$result = wp_update_post($post_data, true);
		}

        if (isset($deals[$property_key])) {
            update_field($acf_field_key, $deals[$property_key], $post_id);
            
        }
    }
    echo 'Deal update';
}

function curl_request($url, $token) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer $token",
        "Content-Type: application/json"
    ));
    $response = curl_exec($ch);
    curl_close($ch);
    $r = json_decode($response, true);
    return $r;
}
