<?php
/**
 * Template Name: Rent Comp 111
 */

get_header(); ?>
<style>
	body {padding-top:50px;}
	
	.main-menu li {float:left; list-style: none; color:#000; margin:-2px 10px 0;}
	.main-menu li a {color:#234621; background:#e3e3e3; padding:15px 30px; font-size:14px;}
	.main-menu li a:hover {color:#FFF; background:#234621; padding:15px 30px; font-size:14px; transition:.3s all;}
	h2 {font-size:32px; font-weight:800; text-transform: uppercase; letter-spacing: 1px;}
	.rentcomps {width:100%; float:left; padding:0px 0 0px 0; margin:0 0 0 0; background:#FFF;}
	.rent-item {width:100%; float:left; padding:100px 0; margin:0 0 0px 0; border-bottom:5px solid #b6763c;}
	.rent-item:last-child {border-bottom:none;}
	.border {border-bottom:5px solid #b6763c !important;}
	.rent-item h1 { color:#000; text-transform: none; font-weight:100; font-size:36px; line-height: 1; margin:30px 0px 15px -5px;}
	.rent-item h2 { color:#000; text-transform: none; font-weight:100; font-size:36px; line-height: 1; margin:30px 0px 0 -5px;}
	.rentcomps h3 {color:#000; font-weight:100;}
	.rent-item .address{ font-size:18px; color:#666; letter-spacing: 1px; margin:0 0px 0 0px;}
	.rent-item .comp-stats strong {color:#b6763c; font-weight:500; text-transform: uppercase; letter-spacing: 1px;}
	.rent-item .comp-stats {margin:30px 0 0 5px;color:#000; font-size:18px; font-weight:500; text-transform: uppercase; letter-spacing: 1px;}
	.rent-hero .columns {padding-left:0px;}
	.cs {background:#e3e3e3; padding:5px 15px; margin:3px 0; margin-left:-5px; float:left; width:100%;}
	.rent-detials {width:100%; float:left;}
	table {width:100%; float:left; margin:50px 0 0 0; border:none; background:none; font-size:14px;}
	tbody {background:transparent; border:none;}
	tbody tr {color:#000; text-align: center;}
	tbody td {border-right:1px solid rgba(255,255,255,0.2);}
	tbody td:last-child {border-right:none}
	tbody tr:nth-child(odd) {background:transparent !important;}
	tbody tr:nth-child(even) {background:#e3e3e3;}
	thead {border:none;}
	thead tr.headerrow {background:#234621; color:#FFF; border:none; text-align: center !important; text-transform: uppercase; letter-spacing: 1.5px;}
	.headerrow th {text-align: center;}
	.averages td {background:#b6763c; color:#FFF; font-weight:700;}
	.amenities {float:left; width:100%; padding:0; margin:0;}
	.amenities h3 {font-size:18px; font-weight:500; color:#000; float:left; width:100%; text-transform: uppercase; letter-spacing: 1px; margin: 30px 0px 0 20px;}
	.amenities ul {float:left; margin:0 30px; width:100%;}
	.amenities li {float:left; padding:0 5px; margin-right:20px; color:#999; font-size:14px; line-height: 2; }
	.amenities p, .amenities div, .amenities span {color:#999; margin:0 20px; font-size:14px; line-height: 2;}
	.disclaimer {margin-top:15px !important; font-size:12px !important; font-style: italic; float:left;}
	
	.other_comments {float:left; width:100%; padding:0; margin:0;}
	.other_comments h3 {font-size:18px; font-weight:500; color:#000; float:left; width:100%; text-transform: uppercase; letter-spacing: 1px; margin: 30px 0px 0 20px;}
	.other_comments ul {float:left; margin:0 0 0 30px; width:100%;}
	.other_comments li {float:left; padding:0 5px; margin-right:20px; color:#999; }
	.other_comments p, .amenities div, .amenities span {color:#999; margin-left:20px;}
	
	.fees-utilities {width:100%; float:left;}
	.fees-utilities h3 {font-size:18px; font-weight:500; color:#000; float:left; width:100%; text-transform: uppercase; letter-spacing: 1px; margin: 30px 0px 0 0px;}
	.fees-utilities .subitem {color:#666; font-size:14px; line-height: 2;}
	
	@media only screen and (max-width: 800px) {
		.rent-item {padding-left:20px;}
		.rent-item .comp-stats {margin-left:0px; width:100%; float:left;}
		.cs {margin-left:0px;}
		tbody td {border-right:none;}

	}
	@media print {
		.rent-item h2 {font-size: 26px !important;margin-left: 0;}
		.rent-item .address {font-size: 16px;}
		.large-8 {width: 63%;padding-right: 0;}
		.rent-detials th {color: #FFF;font-size: 13px;}
		.rent-detials td {color: #FFF;text-align: center;font-size: 13px;}
		.rent-item .comp-stats {font-size: 16px;}
		.rent-detials .large-6 {padding-right: 0;}
		.rent-detials tbody td {border-right: 1px solid rgba(255,255,255,0.1);}
		.rent-details {page-break-inside: avoid;}
		.footer .large-3 {padding-right: 0;width: 23%;height: 220px;}
		.footer a {text-decoration: none;} 
		.footer .large-6 {padding-right: 0;width: 46%;height: 220px;}
		.social {width: 20px;height: 32px;display: inline-block;max-width: 30mm;max-height: 20mm;margin-top: 80px;}
		#menu {display: none;}
		.header-menu {display: none;}
		.rent-item {padding: 80px 0;}
		.redwood img {max-width: 20px;height: auto;width: 20px;}
		.footer .social {display: inline-block;width: 20px;}
	}
	.row-color{ background-color:#b6763c !important; color:#FFF !important;}
		 tr:nth-child(odd).row-color {background-color:#b6763c !important; color:#FFF !important;}

	.stats{margin:0px; margin-top: 10px;}
	.listStats{margin:0px 0 100px; float:left; width: 100%;}

	.listStats h2 { color:#000; text-transform:capitalize; font-weight:100; font-size:24px; line-height: 1; margin:30px 0px 0 -5px;}
</style>

<div class="rentcomps">
	<div class="row small-11 small-centered">
		
		<?php 
			
			$unit_types = [];
			
			$property_details = acf_get_field('property_details');
			
			$unit_type = acf_get_sub_field( 'unit_type', $property_details );
			
			$unit_types = array_values($unit_type['choices']);
			
			function convertToAbbreviationPage($input) {
				// Remove spaces and slashes
				$cleaned = preg_replace('/\s+|\//', '', $input);
				
				// Convert to lowercase
				return strtolower($cleaned);
				
			}
			
			function convertToFullNamePage($input) {
				// Define regular expressions to match patterns like "1 Bdrm / 1 Bath" or "2 Bdrm / 2 Bath"
				//$pattern = '/(\d+)\s*Bdrm\s*\/\s*(\d+)\s*Bath/i';
				$pattern = '/(\d+(\.\d+)?)\s*Bdrm\s*\/\s*(\d+(\.\d+)?)\s*Bath/i';

				// Use preg_replace_callback to replace matches using a callback function
				return preg_replace_callback($pattern, function($matches) {
					//pr($matches);
					$bedrooms = intval($matches[1]);
					//$bathrooms = intval($matches[2]);
					$bathrooms = $matches[3];
					
					// Logic to convert to singular if necessary
					$bedroomText = $bedrooms == 1 ? 'Bedroom' : 'Bedrooms';
					$bathroomText = $bathrooms == 1 ? 'Bathroom' : 'Bathrooms';
					
					return "$bedrooms $bedroomText and $bathrooms $bathroomText";
				}, $input);
			}
			
		?>
		<?php if( have_rows('rent_comps') ): ?>
			<?php while ( have_rows('rent_comps') ) : the_row(); ?>
				<?php $post_object = get_sub_field('comp'); ?>
					<?php if( $post_object ): ?>
						<?php $post = $post_object; setup_postdata( $post ); ?>
							<div class="rent-item">
									<div class="large-12 large-centered">
										<div class="rent-hero">
											<!-- Adds in the Subject Property Header when checkbox is true -->
											<?php if( get_sub_field('subject_property') ) { ?>
												<h1>Subject Property</h1>
											<?php } ?>
											<div class="large-12 columns">
												<img src="<?php the_field('featured_image'); ?>" />
											</div>
											<div class="large-4 columns">
												<h2><?php the_field('dealname'); ?></h2>
												<div class="address">
													<?php the_field('property_address'); ?><br />
													<?php the_field('property_city'); ?>, <?php the_field('property_state'); ?> <?php the_field('property_zip'); ?> 
												</div>
												<div class="comp-stats">
													<div class="cs"><strong>Total Units:</strong> <?php the_field('number_of_units'); ?></div>
													<div class="cs"><strong>Year Built:</strong> <?php the_field('year_built'); ?></div>
													<div class="cs"><strong>Occupancy:</strong> <?php the_field('occupancy'); ?></div>
												</div>
											</div>
											<div class="large-8 columns">
												<div class="rent-detials">
													<?php if( have_rows('property_details') ): ?>
													<table id="table_<?php $post_id = get_the_ID(); echo $post_id;?>">
														<thead >
															<tr class="headerrow">
															<th class="large-3 columns">Unit Type</td>
															<th class="large-3 columns">Unit SF</td>
															<th class="large-3 columns">Asking Rent</td>
															<th class="large-3 columns">Asking Rent / sf</td>
															</tr>
														</thead>
														<tbody>
													<?php while( have_rows('property_details') ): the_row();
														//Storing the ACF fields for future Math
														$unit_square_feet = get_sub_field( 'unit_square_feet', $post_id );
														$asking_rents = get_sub_field( 'asking_rents', $post_id );
														$number_of_units = get_sub_field( 'number_of_units', $post_id );

														//Function to Calculate Asking Rents per Square Feet and then to round the decimals
														$asking_rents_per_square_feet = ($asking_rents / $unit_square_feet);
														$asking_rentspsf_rounded = round($asking_rents_per_square_feet, 2);
														$asking_rentspsf_rounded = number_format($asking_rentspsf_rounded, 2);
													?>
														<tr>
															<td class="large-3 columns"><?php the_sub_field('unit_type') ?></td>
															<td class="large-3 columns unitscalc_<?php echo $post_id;?>"><?php echo esc_html( number_format($unit_square_feet) ); ?></td>
															<td class="large-3 columns rents_<?php echo $post_id;?>"><?php echo '$' . esc_html( $asking_rents ); ?></td>
															<td class="large-3 columns sfcalc_<?php echo $post_id;?>"><?php echo '$' . esc_html( $asking_rentspsf_rounded ); ?></td>
														</tr>
													<?php endwhile; ?>
														<tr class="averages" id="">
															<td class="large-3 columns">Totals / Averages</td>
															<td id="unitsequal_<?php echo $post_id;?>" class="large-3 columns"><span class="val"></span></td>
															<td id="rentsequal_<?php echo $post_id;?>"class="large-3 columns"></td>
															<td id="alga_<?php echo $post_id;?>" class="large-3 columns"></td>
														</tr>
													</tbody>
													</table>
													<script>
														$(document).ready(function(){
															//Average Rents per SF
															var dollar = "$"	  
															var sum = 0;
															var sumrents = 0;
															var sumunits = 0
															var counter = 0 //daliklis
															$('.sfcalc_<?php echo $post_id;?>').each(function() {
																sum += parseFloat($(this).text().replace(/[^\d.-]+/g, ''));
																counter += 1;
															});
															$("#alga_<?php echo $post_id;?>").html(dollar+(sum/counter).toFixed(2));

															$('.rents_<?php echo $post_id;?>').each(function() {
																sumrents += parseFloat($(this).text().replace(/[^\d.-]+/g, ''));
																//counter += 1;
															});
															$("#rentsequal_<?php echo $post_id;?>").html(dollar+Math.round(sumrents/counter));

															$('.unitscalc_<?php echo $post_id;?>').each(function() {
																sumunits += parseFloat($(this).text().replace(/[^\d.-]+/g, ''));
																//counter += 1;
															});
															$("#unitsequal_<?php echo $post_id;?>").html((sumunits/counter).toLocaleString(undefined, {maximumFractionDigits: 0}));
														});
													</script>
													<?php endif; ?>
												</div><!-- End Rent Detials-->
											</div><!-- End Large 8-->
											<div class="rent-detials">
												<div class="large-4 columns">
													<?php if( get_field('amenities') ): ?>
														<div class="amenities">
															<div class="row">
																<h3>Amenities:</h3>
																<p><?php the_field('amenities') ?></p>
																<p class="disclaimer">*Select Units Only</p>
															</div>
														</div>
													<?php endif; ?>
													&nbsp;
												</div><!-- End Large 6-->

												<div class="large-8 columns">
													<div class="fees-utilities">
													<div class="large-7 columns">
														
														<?php if( have_rows('utilities') ): ?>
														<h3>Utilities:</h3>	
															<?php while( have_rows('utilities') ): the_row(); 
														?>
															<div class="subitem"><strong>Water/Sewer: </strong><?php echo the_sub_field('watersewer'); ?></div>
															<div class="subitem"><strong>Electricity: </strong><?php echo the_sub_field('electricity'); ?></div>
															<div class="subitem"><strong>Gas: </strong><?php echo the_sub_field('gas'); ?></div>
															<div class="subitem"><strong>Garbage: </strong><?php echo the_sub_field('garbage'); ?></div>
															<?php if(get_sub_field('concessions')): ?>
																<div class="subitem"><strong>Concessions: </strong><?php echo the_sub_field('concessions'); ?></div>
															<?php endif; ?>

														<?php endwhile; ?>
														<?php endif; ?>										
													</div>
													
													<div class="large-5 columns">
														
														<?php if( have_rows('fees') ): ?>
														<h3>Fees:</h3>
															<?php while( have_rows('fees') ): the_row(); 
														?>
															<div class="subitem"><strong>Deposit: </strong><?= the_sub_field('deposit'); ?> <span style="font-size:12px;">(<?= the_sub_field('deposit_type'); ?>)</span></div>
															<div class="subitem"><strong>Admin Fee: </strong><?= the_sub_field('_admin_fee'); ?> <span style="font-size:12px;">(<?= the_sub_field('admin_fee_type'); ?>)</span></div>
															<div class="subitem"><strong>App Fee: </strong><?= the_sub_field('_app_fee'); ?> <span style="font-size:12px;">(<?= the_sub_field('app_fee_type'); ?>)</span></div>
															<div class="subitem"><strong>Pet Fee: </strong><?= the_sub_field('pet_fee'); ?> <span style="font-size:12px;">(<?= the_sub_field('pet_fee_type'); ?>)</span></div>
															<div class="subitem"><strong>Pet Rent: </strong><?= the_sub_field('pet_rent'); ?> <span style="font-size:12px;">(<?= the_sub_field('pet_rent_type'); ?>)</span></div>
															

														<?php endwhile; ?>
														<?php endif; ?>	
													</div>
													</div> <!-- End Fees and Utilities-->
												</div><!-- End Large 8 -->
												<div class="large-12">
													<?php if( get_field('other_comments') ): ?>
														<div class="other_comments">
															<div class="row">
																<h3>Other Comments:</h3>
																<?php the_field('other_comments') ?>
															</div>
														</div>
													<?php endif; ?>
												</div> <!-- End Large-12-->
											</div><!-- End Rent Detials-->
										</div><!-- End Hero-->
									</div><!-- End Large 12-->
								</div><!-- End Rent Item-->
						<?php wp_reset_postdata(); ?>
					<?php endif; ?>
				<?php endwhile; ?>
			<?php endif; ?>
	</div><!-- End Row-->
	
	<div class="row small-centered">
		<?php 
			foreach ($unit_types as $ut) { 
			$bdrm = convertToAbbreviationPage($ut);
			$fullname = convertToFullNamePage($ut);
			?>
			<div class="listStats" id="<?= $bdrm; ?>-avrg-mnth">
				<h2><?= $fullname; ?> Sorted By - Average Rent / Month</h2>
				<table class='stats'>
					<?php echo createTableHeader(); ?>
					<tbody>
						<?php 
						$all_asking_rents_1b = [];
						if( have_rows('rent_comps') ): ?>
							<?php while ( have_rows('rent_comps') ) : the_row(); ?>
								<?php $post_object = get_sub_field('comp'); ?>
									<?php if( $post_object ): ?>
										<?php $post = $post_object; setup_postdata( $post ); 
										$class = '';
										if( get_sub_field('subject_property') ) {  
											$class = "row-color";
										} 
										if( have_rows('property_details') ):
											while( have_rows('property_details') ): the_row();
												if (str_contains(get_sub_field('unit_type'), $ut)):
													$unit_square_feet = get_sub_field( 'unit_square_feet', $post->ID );
													$asking_rents = get_sub_field( 'asking_rents', $post->ID );
													$number_of_units = get_sub_field( 'unit_count', $post->ID );
													$asking_rents_per_square_feet = ($asking_rents / $unit_square_feet);
													$asking_rentspsf_rounded = round($asking_rents_per_square_feet, 2); 
													$all_asking_rents_1b[] =  array(
														'dealname'=> get_field('dealname'),
														'year_built'=> get_field('year_built'),
														'number_of_units'=>  $number_of_units, //get_field('number_of_units'),
														'unit_square_feet'=>number_format($unit_square_feet),
														'asking_rents'=>$asking_rents,
														'asking_rentspsf_rounded'=>$asking_rentspsf_rounded,
														'class'=>$class
													);
												endif; 
											endwhile;
										endif;
										wp_reset_postdata();
									endif;
							endwhile;
							echo createListing($all_asking_rents_1b,'asking_rents', $bdrm ."-avrg-mnth");
							endif; ?>
					</tbody>
				</table>
			</div>
			<div class="clearfix"></div>	
		<?php } ?>
					
		<?php 
			foreach ($unit_types as $ut) { 
			$bdrm = convertToAbbreviationPage($ut);
			$fullname = convertToFullNamePage($ut);
			?>			
		<div class="listStats" id="<?= $bdrm; ?>-avrg-sq">			
			<h2><?= $fullname; ?> Sorted By - Average Rent / Square Foot</h2>
			<table class="stats">
				<?php echo createTableHeader(); ?>
				<tbody>
					<?php 
					$all_asking_rentspsf_rounded_1b = [];
					if( have_rows('rent_comps') ): ?>
						<?php while ( have_rows('rent_comps') ) : the_row(); ?>
							<?php $post_object = get_sub_field('comp'); ?>
								<?php if( $post_object ): ?>
									<?php $post = $post_object; setup_postdata( $post ); 
									$class = '';
									if( get_sub_field('subject_property') ) {  
										$class = "row-color";
									} 
									if( have_rows('property_details') ):
										while( have_rows('property_details') ): the_row();
											if (str_contains(get_sub_field('unit_type'), $ut)):
												$unit_square_feet = get_sub_field( 'unit_square_feet', $post->ID );
												$asking_rents = get_sub_field( 'asking_rents', $post->ID );
												$number_of_units = get_sub_field( 'unit_count', $post->ID );
												$asking_rents_per_square_feet = ($asking_rents / $unit_square_feet);
												$asking_rentspsf_rounded = round($asking_rents_per_square_feet, 2); 
												$all_asking_rentspsf_rounded_1b[] =  array(
													'dealname'=> get_field('dealname'),
													'year_built'=> get_field('year_built'),
													'number_of_units'=> $number_of_units,
													'unit_square_feet'=>number_format($unit_square_feet),
													'asking_rents'=>$asking_rents,
													'asking_rentspsf_rounded'=>$asking_rentspsf_rounded,
													'class'=>$class
												);
											endif; 
										endwhile;
									endif;
									wp_reset_postdata();
								endif;
						endwhile;
						echo createListing($all_asking_rentspsf_rounded_1b,'asking_rentspsf_rounded', $bdrm ."-avrg-sq");
						?>
						<?php endif; ?>
				</tbody>
			</table>			
		</div>	
		<div class="clearfix"></div>
		<?php } ?>				
		<?php 
			foreach ($unit_types as $ut) { 
			$bdrm = convertToAbbreviationPage($ut);
			$fullname = convertToFullNamePage($ut);
			?>						
		<div class="listStats" id="<?= $bdrm; ?>-avrg-feet">
			<h2><?= $fullname; ?> Sorted By - Average Square Feet</h2>
			<table class="stats">
				<?php echo createTableHeader(); ?>
				<tbody>
					<?php 
					$all_unit_square_feet_1b = [];
					if( have_rows('rent_comps') ): ?>
						<?php while ( have_rows('rent_comps') ) : the_row(); ?>
							<?php $post_object = get_sub_field('comp'); ?>
								<?php if( $post_object ): ?>
									<?php $post = $post_object; setup_postdata( $post ); 
									$class = '';
									if( get_sub_field('subject_property') ) {  
										$class = "row-color";
									} 
									if( have_rows('property_details') ):
										while( have_rows('property_details') ): the_row();
											if (str_contains(get_sub_field('unit_type'), $ut)):
												$unit_square_feet = get_sub_field( 'unit_square_feet', $post->ID );
												$asking_rents = get_sub_field( 'asking_rents', $post->ID );
												$number_of_units = get_sub_field( 'unit_count', $post->ID );
												$asking_rents_per_square_feet = ($asking_rents / $unit_square_feet);
												$asking_rentspsf_rounded = round($asking_rents_per_square_feet, 2); 
												$all_unit_square_feet_1b[] =  array(
													'dealname'=> get_field('dealname'),
													'year_built'=> get_field('year_built'),
													'number_of_units'=> $number_of_units,
													'unit_square_feet'=> number_format($unit_square_feet),
													'asking_rents'=>$asking_rents,
													'asking_rentspsf_rounded'=>$asking_rentspsf_rounded,
													'class'=>$class
												);
											endif; 
										endwhile;
									endif;
									wp_reset_postdata();
								endif;
						endwhile;
						echo createListing($all_unit_square_feet_1b,'unit_square_feet',$bdrm ."-avrg-feet");
						?>
						<?php endif; ?>
				</tbody>
			</table>
		</div>			
		<div class="clearfix"></div>	
		<?php } ?>				

</div><!-- End Rent Comps-->

<script>
//Testimonial Slider
	$(document).ready(function(){
		$('.slide').slick({
			dots: true,
			arrows: false,
			infinite: true,
			speed: 300,
			slidesToShow: 1,
			responsive: [
			{
				breakpoint: 680, // tablet breakpoint
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
			}
				],
			adaptiveHeight: true,
			prevArrow: '<div class="slick-prev"></div>',
			nextArrow: '<div class="slick-next"><img src="<?php echo get_template_directory_uri(); ?>/images/arrow_next.png" /></div>'
		});
	});
</script>
<?php get_footer(); ?>

<?php 
function createTableHeader(){
	return '<thead>
		<tr class="headerrow">
			<th scope="col">Apartment Community</td>
			<th scope="col">Year Built</td>
			<th scope="col">Number of Units</td>
			<th scope="col">Square Feet</td>
			<th scope="col">Average Rent/Month</td>
			<th scope="col">Average Rent/SF</td>
		</tr>
	</thead>';
}


function createListing($all_asking_rents,$sortField,$id){
	$respone_data = '';
	$asking_rents_sort = array_column($all_asking_rents, $sortField); 
	array_multisort($asking_rents_sort, SORT_DESC, $all_asking_rents);
	foreach ($all_asking_rents as $list) { 
		$respone_data .= '<tr class="'.$list['class'].'">	
			<td>'.$list['dealname'].'</td>
			<td>'.$list['year_built'].'</td>
			<td>'.$list['number_of_units'].'</td>
			<td>'.$list['unit_square_feet'].'</td>
			<td>$'.$list['asking_rents'].'</td>
			<td>$'.$list['asking_rentspsf_rounded'].'</td>
		</tr>';
	}
	if($respone_data == ''){
		?>
		<script>$("#<?php echo $id; ?>").hide();</script>
		<?php 
		$respone_data= '<tr><td colspan=6><b>No Record Found</b></td></tr>';
	}

	return $respone_data;
}


