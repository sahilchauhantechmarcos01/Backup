<?php
require_once "../../../wp-load.php";

$log_file1 = 'deleteDeal.log'; // Replace with the path to your log file
$log_file2 = 'updateDeal.log';
$log_file3 = 'createDeal.org';
$max_size = 10 * 1024 * 1024; // 10 MB in bytes

// Check if the file exists and its size exceeds the limit
if (file_exists($log_file) && filesize($log_file) > $max_size) {
    // Clear the file by opening it in write mode, which truncates it
    $handle = fopen($log_file, 'w');
    if ($handle) {
        fclose($handle);
        echo "Log file cleared as it exceeded 10 MB.";
    } else {
        echo "Failed to open the log file.";
    }
} else {
    echo "Log file is within the size limit.";
}

// Check if the file exists and its size exceeds the limit
if (file_exists($log_file2) && filesize($log_file2) > $max_size) {
    // Clear the file by opening it in write mode, which truncates it
    $handle = fopen($log_file2, 'w');
    if ($handle) {
        fclose($handle);
        echo "Log file cleared as it exceeded 10 MB.";
    } else {
        echo "Failed to open the log file.";
    }
} else {
    echo "Log file is within the size limit.";
}


// Check if the file exists and its size exceeds the limit
if (file_exists($log_file3) && filesize($log_file3) > $max_size) {
    // Clear the file by opening it in write mode, which truncates it
    $handle = fopen($log_file3, 'w');
    if ($handle) {
        fclose($handle);
        echo "Log file cleared as it exceeded 10 MB.";
    } else {
        echo "Failed to open the log file.";
    }
} else {
    echo "Log file is within the size limit.";
}