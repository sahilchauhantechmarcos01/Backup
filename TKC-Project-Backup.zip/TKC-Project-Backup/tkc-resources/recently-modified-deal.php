<?php
require_once "../../../wp-load.php";

$dealsData = tkc_recently_modified_deals();

$deals = tkc_prepare_deals($dealsData);

tkc_create_post($deals);
// pr($deals);

$hubspot_recently_modified_deal_offset = get_tkc_option('hubspot_recently_modified_deal_offset');

//file_put_contents('webhook.log', "Offset Modified deals: " . print_r($hubspot_recently_modified_deal_offset, true) . PHP_EOL, FILE_APPEND);
echo  empty($hubspot_recently_modified_deal_offset) ? "This tab will be automatically close in few seconds. Please wait....."  : "This tab will be automatically close in few seconds. Please wait.....";
exit;