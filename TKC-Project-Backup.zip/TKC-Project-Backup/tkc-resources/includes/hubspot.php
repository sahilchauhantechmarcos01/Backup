<?php
function get_connected_account($token) {
    $headers = [
        "Content-Type: application/x-www-form-urlencoded"
    ];
    $options = [
        CURLOPT_URL => "https://api.hubapi.com/oauth/v1/refresh-tokens/" . $token,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true
    ];
    $ch = curl_init();
    curl_setopt_array($ch, $options);
    $response = curl_exec($ch);

    curl_close($ch);
    $res = json_decode($response, true);

    save_tkc_option('hubspot_connected_account', $res['hub_domain']);
}

function tkc_get_hs_response($code) {
    $refreshToken = tkc_get_hs_access_token($code);

    save_tkc_option('hubspot_refresh_token', $refreshToken);

    get_connected_account($refreshToken);
}

function tkc_get_hs_access_token($code) {


    $hubspot_client_id = get_tkc_option('hubspot_client_id');
    $hubspot_secret_key = get_tkc_option('hubspot_secret_key');

    $data = [
        "grant_type" => "authorization_code",
        "client_id" => $hubspot_client_id,
        "client_secret" => $hubspot_secret_key,
        "redirect_uri" => TKC_URL . "hubspot-connect.php",
        "code" => $code
    ];
    $headers = [
        "Content-Type: application/x-www-form-urlencoded"
    ];
    $options = [
        CURLOPT_URL => 'https://api.hubapi.com/oauth/v1/token',
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($data),
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true
    ];
    $ch = curl_init();
    curl_setopt_array($ch, $options);
    $response = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($response, true);
    return $result['refresh_token'];
}

function tkc_get_fersh_token() {

    $hubspot_client_id = get_tkc_option('hubspot_client_id');
    $hubspot_secret_key = get_tkc_option('hubspot_secret_key');
    $refresh_token = get_tkc_option('hubspot_refresh_token');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.hubapi.com/oauth/v1/token');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    $data = array(
        'grant_type' => 'refresh_token',
        'client_id' => $hubspot_client_id,
        'client_secret' => $hubspot_secret_key,
        'refresh_token' => $refresh_token
    );
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    $response = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($response, true);

    if (!empty($result['refresh_token'])) {
        save_tkc_option('hubspot_refresh_token', $result['refresh_token']);
        return  $result['access_token'];
    }

    return "access token not found";
}

function tkc_get_deals($deals = [], $offset = 0, $limit = 250) {


    $hubspot_all_deal_offset = get_tkc_option('hubspot_all_deal_offset');

    if (!empty($hubspot_all_deal_offset)) {
        $offset = $hubspot_all_deal_offset;
    }


    $access_token = tkc_get_fersh_token();

    $base_url = "https://api.hubapi.com";
    $endpoint = "/deals/v1/deal/paged?limit=" . $limit . "&offset=" . $offset;
    //$endpoint = "/deals/v1/deal/7030188430";

    $ch = curl_init();
    $payload = [
        //'filters' => array(array("propertyName" => "petra_engagement", "operator" =>  "EQ", "value" => "Member")),
        //'sorts' => array(array("propertyName" => "name", "direction" => "ASCENDING")),
        'properties' => [
            'dealname',
            'dealstage',
            'property_name',
            'property_address',
            'property_city',
            'property_state',
            'property_zip',
            'property_state_dropdown',
            'year_built',
            'hubspot_owner_id',
            'division',
            'number_of_units',
        ],
    ];
    curl_setopt($ch, CURLOPT_URL, $base_url . $endpoint);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer $access_token",
        "Content-Type: application/json"
    ));
    $response = curl_exec($ch);
    curl_close($ch);
    $r = json_decode($response, true);
    // pr($r);
    // die;

    if (!empty($r['deals'])) {

        foreach ($r['deals'] as $deal) {
            $deals[] =  $deal;
        }

        //&& $r['offset'] <= 7030312893
        if ($r['hasMore']) {
            save_tkc_option('hubspot_all_deal_offset', $r['offset']);
            //return tkc_get_deals($deals, $r['offset']);
        } else {
            save_tkc_option('hubspot_all_deal_offset', '0');
        }
    }

    return $deals;
}

add_action('wp_ajax_tkc_hs_disconnect', 'tkc_hs_disconnect');
function tkc_hs_disconnect() {
    save_tkc_option('hubspot_refresh_token', '');
}

function tkc_prepare_deals($dealsData) {
    


    $deal_stages = [
        '7597106' => "Leads",
        'appointmentscheduled' => "Numbers",
        'qualifiedtobuy' => "Listing",
        'presentationscheduled' => "Under Contract (Listed)",
        'decisionmakerboughtin' => "Under Contract (Off-Market)",
        'closedwon' => "Closing",
        '51518753' => "Holding - BR",
    ];

    $deals = [];
    $dealCount = 0;

    foreach ($dealsData as $deal){
            $deals[$dealCount] = [
                'deal_id' => empty($deal['dealId']) ? $deal['deal_id']: $deal['dealId'],
                'property_id' => empty($deal['propertyId']) ? $deal['property_id'] :  $deal['propertyId']
            ]; 
            foreach ($deal['properties'] as $name => $property) {
                switch ($name) {
                    case "dealstage": {
                            $deals[$dealCount]['deal_stage'] = $deal_stages[$property['value']];
                            $deals[$dealCount]['deal_stage'] = $property['value'];
                            break;
                        }
                    case "dealname": {
                            $deals[$dealCount]['deal_name'] = $property['value'];
                            $deals[$dealCount]['property_name'] = $property['value'];
                            break;
                        }
                    case "property_state_dropdown": {
                        $deals[$dealCount]['property_state'] = $property['value'];
                        
                        break;
                    }
                    case "hs_object_id": {
                        $deals[$dealCount]['deal_id'] = $property['value'];
                        
                        break;
                    } 	
                    default: {
                            $deals[$dealCount][$name] = $property['value'];
                        }
                } 
            }
            $dealCount++;
        
    }
    return $deals;
}

function tkc_create_post($deals = []) {

    $acf_field_mapping = [
        'deal_id' => 'hs_object_id',
        'division' => 'division',
        'deal_name' => 'dealname',
        'deal_stage' => 'dealstage',
        'property_name' => 'property_name',
        'property_address' => 'property_address',
        'property_city' => 'property_city',
        'property_state' => 'property_state',
        'zip_code' => 'property_zip',
        'year_built' => 'year_built',
        'number_of_units' => 'number_of_units',
    ];
    $stages =   ["Leads", "Numbers", "Listing", "Under Contract (Listed)", "Under Contract (Off-Market)"];
	$stages = [ '7597106', 'appointmentscheduled', 'qualifiedtobuy', 'presentationscheduled', 'decisionmakerboughtin' ];

    // Loop through each deal
    foreach ($deals as $deal) {
	    if (
            in_array($deal['deal_stage'], $stages)
            && !empty($deal['deal_name'])
            && !empty($deal['property_name'])
            && !empty($deal['property_address'])
            && !empty($deal['property_city'])
            && !empty($deal['property_state'])
            //&& $deal['deal_id'] == '33636498465'
        ) {
			
			//pr($deal);
			
			//pr($deal['deal_id']);
            $post_id = tkc_get_post_id_by_meta_key_and_value('hs_object_id', $deal['deal_id']);
            
            //pr($post_id);
            // The Loop
            if (!$post_id) {
               // file_put_contents('createDeal.log', "Create post deal data: " . print_r($deal, true) . PHP_EOL, FILE_APPEND);    
                // Create a new post
                $post_id = wp_insert_post(array(
                    'post_title' => $deal['deal_name'],
                    'post_status' => 'publish',
                    'post_type' => 'rentcomps', // Change this to your custom post type if necessary
                ));
            }

            // Update ACF fields
            foreach ($acf_field_mapping as $property_key => $acf_field_key) {
                if (isset($deal[$property_key])) {
                   // file_put_contents('updateDeal.log', "Update post data: " . print_r($deal, true) . PHP_EOL, FILE_APPEND);
                    update_field($acf_field_key, $deal[$property_key], $post_id);
                    if($property_key == 'deal_name'){
						$post_data = array(
							'ID'          => $post_id,
							'post_title' => $deal['deal_name'],         // The post ID
							'post_status' => 'publish'         // The new post status (e.g., 'publish', 'draft', 'pending', 'private', etc.)
						);
                    
						wp_update_post( $post_data );
					}
                }
            }
            
            $deal_name = empty($deal['deal_name']) ? '' : $deal['deal_name'];
            $property_name = empty($deal['property_name']) ? '' : $deal['property_name'];
            $property_address = empty($deal['property_address']) ? '' : $deal['property_address'];
            $property_city = empty($deal['property_city']) ? '' : $deal['property_city'];
            $property_state = empty($deal['property_state']) ? '' : $deal['property_state'];
            
            //Check for duplicates:
            check_duplicate($deal_name, $property_name, $property_address, $property_city, $property_state);
        }
        // Optionally, you can also update other non-ACF fields using the post ID
        // update_post_meta($post_id, 'meta_key', 'meta_value');
    }
}

function check_duplicate($deal_name, $property_name, $property_address, $property_city, $property_state)
{
    $args = [
        'post_title'  => esc_sql($deal_name),
        'post_type'  => 'rentcomps',
        'post_status'  => 'publish',
        'meta_query' => [
            'relation' => 'AND',
            [
                'key'   => 'dealname',
                'value' => esc_sql($deal_name),
            ],
            //[
            //    'key'   => 'property_name',
            //    'value' => esc_sql($property_name),
            //],
            // [
            //     'key'   => 'property_address',
            //     'value' => esc_sql($property_address),
            // ],
            [
                'key'   => 'property_city',
                'value' => esc_sql($property_city),
            ],
            [
                'key'   => 'property_state',
                'value' => esc_sql($property_state),
            ]
        ],
        'fields' => 'ids',
    ];
    
    //pr($args);

    $query = new WP_Query($args);
    $post_ids = $query->posts;

    //pr($post_ids); 

    $all_deals = [];
    if (!empty($post_ids)) {
        if (count($post_ids) > 1) {
            foreach ($post_ids as $post_id) {
                $all_deals[$post_id] = get_post_meta($post_id, 'hs_object_id', true);
            }
            arsort($all_deals);

            //pr($all_deals); die;
            $keep_first = true;
            foreach ($all_deals as $post_id => $hs_object_id) {
                if ($keep_first) {
                    $keep_first = false; // Skip the first post
                    continue;
                }

                // Update post status to 'archive'
                wp_update_post([
                    'ID'          => $post_id,
                    'post_status' => 'trash',
                ]);
            }
        }
    }
}

function tkc_get_post_id_by_meta_key_and_value($key, $value) {
    global $wpdb;
    $meta = $wpdb->get_results("SELECT * FROM `" . $wpdb->postmeta . "` WHERE meta_key='" . esc_sql($key) . "' AND meta_value='" . esc_sql($value) . "'");
    if (is_array($meta) && !empty($meta) && isset($meta[0])) {
        $meta = $meta[0];
    }
    if (is_object($meta)) {
        return $meta->post_id;
    } else {
        return false;
    }
}

/**
 * @description Function to fetch recently created deals
 * @link https://legacydocs.hubspot.com/docs/methods/deals/get_deals_created
 * @param array $deals
 * @param int $offset 
 * @param string $since
 * @param int $count
 * @return mixed
 * */
function tkc_recently_created_deals($deals = [], $offset = 0, $count = 100) {

    $hubspot_recently_created_deal_offset = get_tkc_option('hubspot_recently_created_deal_offset');

    if (!empty($hubspot_recently_created_deal_offset)) {
        $offset = $hubspot_recently_created_deal_offset;
    }

    $since = strtotime("-15 minutes")* 1000; // Get data of past one week
    $access_token = tkc_get_fersh_token();
    echo "Access Token: " . $access_token;
    $base_url = "https://api.hubapi.com";
    $endpoint = "/deals/v1/deal/recent/created?since=" . $since . "&offset=" . $offset . "&count=" . $count;

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $base_url . $endpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer $access_token",
        "Content-Type: application/json"
    ));
    $response = curl_exec($ch);
    curl_close($ch);
    $r = json_decode($response, true);

    if (!empty($r['results'])) {

        foreach ($r['results'] as $deal) {
            $deals[] =  $deal;
        }

        //&& $r['offset'] <= 7030312893
        // if ($r['hasMore']) {
        //     return tkc_recently_created_deals($deals, $r['offset']);
        // }

        if ($r['hasMore']) {
            save_tkc_option('hubspot_recently_created_deal_offset', $r['offset']);
            //return tkc_recently_created_deals($deals, $r['offset']);
        } else {
            save_tkc_option('hubspot_recently_created_deal_offset', '0');
        }
    }

    return $deals;
}

/**
 * @description Function to fetch recently modified deals
 * @link https://legacydocs.hubspot.com/docs/methods/deals/get_deals_modified
 * @param array $deals
 * @param int $offset 
 * @param int $count
 * @return mixed
 * */
function tkc_recently_modified_deals($deals = [], $offset = 0, $count = 100) {
    $hubspot_recently_modified_deal_offset = get_tkc_option('hubspot_recently_modified_deal_offset');
    if (!empty($hubspot_recently_modified_deal_offset)) {
        $offset = $hubspot_recently_modified_deal_offset;
    }
    //$since = strtotime("-15 minutes")* 1000; // Get data of past one week
    $since = strtotime("-15 minutes")* 1000; // Get data of past one week
    $access_token = tkc_get_fersh_token();
    $base_url = "https://api.hubapi.com";
    if(isset($_GET['pi'])){
        $deal_id = $_GET['pi'];
        global $wpdb;
        $result = $wpdb->get_results("SELECT meta_value FROM $wpdb->postmeta where post_id=$deal_id and meta_key='hs_object_id'");
        $dealId = $result[0]->meta_value;
        $endpoint = "/deals/v1/deal/$dealId";
    } else {
        $endpoint = "/deals/v1/deal/recent/modified?since=" . $since;
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $base_url . $endpoint);
    // curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer $access_token",
        "Content-Type: application/json"
    ));
    $response = curl_exec($ch);
    curl_close($ch);
    $r = json_decode($response, true);

    if (!empty($r['results'])) {
        foreach ($r['results'] as $deal) {
            $deals[] =  $deal;
        }
        if ($r['hasMore']) {
            save_tkc_option('hubspot_recently_modified_deal_offset', $r['offset']);
        } else {
            save_tkc_option('hubspot_recently_modified_deal_offset', '0');
        }
    } else {
        $deals[] =  $r;
    }
    return $deals;
}


//----------Created by Avi - 07-November 2024 ---------------------
function curl_request($url,$token,$delete='no'){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    if($delete == 'yes'){
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");     
    }    
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer $token",
        "Content-Type: application/json"
    ));
    $response = curl_exec($ch);
    curl_close($ch);
    $r = json_decode($response, true); 
    return $r;
}

function get_recently_created_deals($deals = [], $offset = 0) {
    $count = 100;
    $since = strtotime("-15 minutes") * 1000; // Get data from the past 15 minutes
    $access_token = tkc_get_fersh_token();
    $base_url = "https://api.hubapi.com";
    $endpoint = "/deals/v1/deal/recent/created?since=" . $since . "&offset=" . $offset . "&count=" . $count;
    $response = curl_request($base_url.$endpoint,$access_token);
    if (!empty($response['results'])) {
        $deals = array_merge($deals, $response['results']);  
    }
    if (is_array($response) && isset($response['hasMore']) && isset($response['offset'])) {
        if ($response['hasMore'] && !empty($response['offset'])) {
            return get_recently_created_deals($deals, $response['offset']);
        } else {
            return $deals; 
        }
    } else {
        return $deals;
    }
}


function get_recently_modified_deals($deal_id, $deals = [], $offset = 0) {
    $count = 100;
    $since = strtotime("-15 minutes")* 1000;
    $access_token = tkc_get_fersh_token();
    $base_url = "https://api.hubapi.com";
    if($deal_id != ''){
        $dealId = get_post_meta($deal_id, 'hs_object_id', true);
        $endpoint = "/deals/v1/deal/$dealId";
    } else {
        $endpoint = "/deals/v1/deal/recent/modified?since=" . $since . "&offset=" . $offset . "&count=" . $count;;
    }
    $response = curl_request($base_url.$endpoint,$access_token);
    if (!empty($response['results'])) {
        $deals = array_merge($deals, $response['results']);  
    } else {
        $deals[] = $response;
    }
    
    if (is_array($response) && isset($response['hasMore']) && isset($response['offset'])) {
        if ($response['hasMore'] && !empty($response['offset'])) {
            return get_recently_modified_deals('',$deals, $response['offset']);
        } else {
            return $deals; 
        }
    } else {
        return $deals;
    }
}

function get_recently_deleted_deals($endpoint, $deals = []){
    // Get current offset from the database
    $access_token = tkc_get_fersh_token();  
    $response = curl_request($endpoint,$access_token);
    if (!empty($response['results'])) {
        foreach($response['results'] as $deal){
            $deals[] = $deal['id'];  
        }
    }
    if (is_array($response) && isset($response['paging'])) {
        if ($response['paging'] && !empty($response['paging']['next'])) {
            return get_recently_deleted_deals($response['paging']['next']['link'],$deals);
        } else {
            return $deals; 
        }
    } else {
        return $deals;
    }
}
    
