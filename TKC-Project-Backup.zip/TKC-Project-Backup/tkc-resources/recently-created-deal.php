<?php
require_once "../../../wp-load.php";

$dealsData = tkc_recently_created_deals();
$deals = tkc_prepare_deals($dealsData);

tkc_create_post($deals);

$hubspot_recently_created_deal_offset = get_tkc_option('hubspot_recently_created_deal_offset');

echo  empty($hubspot_recently_created_deal_offset) ? "All Deals Fetched"  : "Next Offset: " . $hubspot_recently_created_deal_offset;

exit;
