<?php
require_once "../../../wp-load.php";

// if url hit from wordpress admin panel
$deal_id = '';
if(isset($_GET['pi'])){
    $deal_id = $_GET['pi'];
}
// recursively called till getting values in hasMore param
$dealsData = get_recently_modified_deals($deal_id);

// preapre deals to insert into DB
$deals = tkc_prepare_deals($dealsData);

echo "Total Deals: ";
echo count($deals);
echo "<br />";

echo "<pre>"; print_r($deals); echo "</pre>";

//create/update deals in the database
tkc_create_post($deals);

echo 'All Modified Deal fetched & created in WP -- NEW';

exit;
