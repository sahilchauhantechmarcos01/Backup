<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', true);
ini_set('display_startup_errors', 1);

require_once "../../../wp-load.php";


//~ if(TKC_DEBUG){
	//~ error_reporting(E_ALL);
	//~ ini_set('display_errors', true);
//~ }


// Get current offset from the database
$close_deal_link= get_tkc_option('close_deal_link');
if (!empty($close_deal_link)) {
    $endpoint = $close_deal_link;
} else {
    $endpoint = "https://api.hubapi.com/crm/v3/objects/deals?limit=20&archived=true";
    save_tkc_option('close_deal_link', '0');
}
$access_token = tkc_get_fersh_token();  
$response = curl_request($endpoint,$access_token);


if(isset($response['paging']) &&  $response['paging']){
    save_tkc_option('close_deal_link', $response['paging']['next']['link']);
} else{
    save_tkc_option('close_deal_link', '0');
}

file_put_contents('deleteDeal.log', "API URL: " . print_r($endpoint, true) . PHP_EOL, FILE_APPEND);
file_put_contents('deleteDeal.log', "API Response: " . print_r($response, true) . PHP_EOL, FILE_APPEND);


if(!empty($response['results'])){
    checkDealsTodelete($response);
}

function checkDealsTodelete($response){
    global $wpdb;
    foreach($response['results'] as $deal) {
        $dealId = $deal['id'];
        file_put_contents('deleteDeal.log', "Checking deal exist in DB: " . print_r($dealId, true) . PHP_EOL, FILE_APPEND);
        // check deal exit in our database 
        $existing_deal_ids = $wpdb->get_results("SELECT posts.id,post_meta.meta_value FROM $wpdb->postmeta AS post_meta 
                JOIN $wpdb->posts AS posts ON post_meta.post_id = posts.ID 
                WHERE post_meta.meta_key = 'hs_object_id' AND posts.post_type = 'rentcomps' AND post_meta.meta_value = $dealId");
                if(!empty($existing_deal_ids)){
                    foreach($existing_deal_ids as $value){   // remove foreach
                        //  pr(value);
                        // check deal is used in pages or not    
                        file_put_contents('deleteDeal.log', "Dean found in DB: " . print_r($value->id, true) . PHP_EOL, FILE_APPEND);   
                        $result = $wpdb->get_results("SELECT * FROM $wpdb->postmeta where meta_value=$value->id");
                        if($result){
                            $post_id = get_post_id_by_rentcomp($result);
                            if ($post_id !== null) {
                                delete_post_and_meta($post_id,$dealId);
                            } else {
                                file_put_contents('deleteDeal.log', "The Deal is used in the pages we can't delete: " . print_r($post_id, true) . PHP_EOL, FILE_APPEND);
                            }
                        } else {
                            delete_post_and_meta($value->id,$dealId);
                        }          
                    }
                    file_put_contents('deleteDeal.log', "-----------------Next Deal check--- " . PHP_EOL, FILE_APPEND);
                }     
    }
}

if(!function_exists('curl_request')){
	function curl_request($url,$token,$delete='no'){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		if($delete == 'yes'){
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");     
		}    
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			"Authorization: Bearer $token",
			"Content-Type: application/json"
		));
		$response = curl_exec($ch);
		curl_close($ch);
		$r = json_decode($response, true); 
		return $r;
	}
}

function get_post_id_by_rentcomp($array) {
    foreach ($array as $item) {
        if (strpos($item->meta_key, 'rent_comps_') !== 0) { // Check if meta_key starts with 'rentcomp_'
            file_put_contents('deleteDeal.log', "The Deal is not used in the pages, we can delete." . print_r($item->post_id, true) . PHP_EOL, FILE_APPEND);
            return $item->post_id; // Return the post_id if found
        }
    }
    return null; // Return null if not found
}

function delete_post_and_meta($post_id,$dealId) {
    //wp_delete_post($post_id, true); permanent delete
    wp_trash_post($post_id); //soft delete
    file_put_contents('deleteDeal.log', "Delete post: " . print_r($post_id, true) . "Delete Deals: " . print_r($dealId, true) . PHP_EOL, FILE_APPEND);
    echo "Post ID $post_id, Deal ID $dealId and its meta have been deleted." . '<br/>';
}
