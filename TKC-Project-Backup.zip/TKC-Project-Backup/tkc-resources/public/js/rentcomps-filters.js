jQuery(document).ready(function($){
    $('#filter_state').change(function(){
        var state = $(this).val();

        $.post(rentcomps_ajax.ajax_url, {
            action: 'get_cities_by_state',
            state: state
        }, function(response){
            var $city = $('#filter_city');
            $city.empty().append('<option value="">Select City</option>');
            $.each(response, function(i, city){
                $city.append('<option value="'+city+'">'+city+'</option>');
            });
        });
    });
});
