jQuery(document).ready(function () {
    jQuery('#run-cron-job').click(function () {
        let cronUrls = Object.values(cron_ajax_object.cron_urls);
        let totalSteps = cronUrls.length;
        let completedSteps = 0;

        jQuery('#run-cron-job').html('Fetching...').prop('disabled', true);

        function runCron(url) {
            jQuery.ajax({
                url: url,
                type: 'GET',
                success: function () {
                    completedSteps++;
                    if (completedSteps === totalSteps) {
                        jQuery('#run-cron-job').html('Run HubSpot Sync').prop('disabled', false);
                    }
                },
                error: function () {
                    jQuery('#run-cron-job').html('Error running cron jobs');
                    setTimeout(function () {
                        jQuery('#run-cron-job').html('Run HubSpot Sync').prop('disabled', false);
                    }, 2000);
                }
            });
        }

        cronUrls.forEach(runCron);
    });
});
