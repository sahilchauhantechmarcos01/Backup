(function ($) {
  var downloadingPdf = false;
  $("#tkcDownloadHorizontalPdf").click(function (e) {
    e.preventDefault();

    if (!downloadingPdf) {
      $.ajax({
        type: "POST",
        url: tkc_object.ajax_url,
        data: {
          action: "tkc_download_pdf_horizontal",
          url: addQueryParam(window.location.href, "format", "pdf"),
        },
        dataType: "json",
        beforeSend: function () {
          downloadingPdf = true;
          $("#tkcDownloadPdf").html("Downloading...");
        },
        success: function (response) {
          console.log(response);
          downloadingPdf = false;
          $("#tkcDownloadPdf").html("Horizontal Export");

          window.open(response.pdf_url, "_blank");
        },
      });
    }
  });
  
  $("#tkcDownloadVerticalPdf").click(function (e) {
    e.preventDefault();

    if (!downloadingPdf) {
      $.ajax({
        type: "POST",
        url: tkc_object.ajax_url,
        data: {
          action: "tkc_download_pdf_vertical",
          url: addQueryParam(window.location.href, "format", "pdf"),
        },
        dataType: "json",
        beforeSend: function () {
          downloadingPdf = true;
          $("#tkcDownloadPdf2").html("Downloading...");
        },
        success: function (response) {
          console.log(response);
          downloadingPdf = false;
          $("#tkcDownloadPdf2").html("Vertical Export");

          window.open(response.pdf_url, "_blank");
        },
      });
    }
  });
  /*$("#tkcDownloadXml").click(function (e) {
    e.preventDefault();
    if (!downloadingPdf) {
      $('#url').val('')
      $("#myModal").css("display","block");
    }  
  });*/

  $('#tkcDownloadXml').click(function() {
      //var baseUrl = $('#url').val();
      $.ajax({
        type: "POST",
        url: tkc_object.ajax_url,
        data: {
          action: "tkc_download_xml",
          url: addQueryParam(window.location.href, "format", "xml"),
          //baseurl: baseUrl
        },
        dataType: "json",
        beforeSend: function () {
          downloadingPdf = true;
          //$("#myModal").css("display", "none");
          $("#tkcDownloadXml").html("Downloading...");
        },
        success: function (response) {
          console.log(response);
          downloadingPdf = false;
          $("#tkcDownloadXml").html("Export XML");
          window.open(response.xml_url, "_blank");
          //window.open(response.zip_file, "_blank");
        },
      });
  });

  $('#tkcDownloadXlsx').click(function() {
   
    $.ajax({
      type: "POST",
      url: tkc_object.ajax_url,
      data: {
        action: "tkc_download_xlsx",
        url: addQueryParam(window.location.href, "format", "xlsx"),
        //baseurl: baseUrl
      },
      dataType: "json",
      beforeSend: function () {
        downloadingPdf = true;
        $("#tkcDownloadXlsx").html("Downloading...");
      },
      success: function (response) {
        console.log(response);
        downloadingPdf = false;
        $("#tkcDownloadXlsx").html("Export XLSX");
        window.open(response.xlsx_url, "_blank");
        //window.open(response.zip_file, "_blank");
      },
    });
});


  function addQueryParam(url, paramName, paramValue) {
    // Check if the URL already has query parameters
    const hasQuery = url.indexOf("?") !== -1;

    // Construct the new parameter string
    const newParam =
      encodeURIComponent(paramName) + "=" + encodeURIComponent(paramValue);

    // Append the new parameter to the URL appropriately
    if (hasQuery) {
      // URL already has query parameters
      return url + "&" + newParam;
    } else {
      // URL does not have query parameters
      return url + "?" + newParam;
    }
  }
})(jQuery);
