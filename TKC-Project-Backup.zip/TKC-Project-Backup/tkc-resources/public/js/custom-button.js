jQuery(document).ready(function($) {
    window.reloadAndClose = function(postId) {
        $('#hs-sync-loader').show();
        // Ensure ajax_object is available
        if (typeof ajax_object !== 'undefined' && ajax_object.background_url) {
            $.ajax({
                url: ajax_object.background_url,
                method: 'GET',
                success: function(response) {
                    console.log("Background request successful");
                    location.reload(); // Optionally reload the page
                },
                error: function(xhr, status, error) {
                    console.log("Background request failed:", error);
                },
                complete: function() {
                    // Hide the loader after request completes
                    $('#hs-sync-loader').hide();
                }
            });
        } else {
            console.error("ajax_object is not defined or URL is missing");
            $('#hs-sync-loader').hide(); // Hide loader if there's an error
        }
    };
});