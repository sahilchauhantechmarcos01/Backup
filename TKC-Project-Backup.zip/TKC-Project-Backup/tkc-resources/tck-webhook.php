<?php
// //pr(__DIR__ . '/vendor/autoload.php');
//require_once __DIR__ . '/vendor/autoload.php';
//~ require_once "../../../wp-load.php";
//~ // Receive the webhook data
//~ $webhookData = file_get_contents('php://input');
//~ $decodedData = json_decode($webhookData, true);


//~ // Handle the data as needed
//~ // For example, log the data to a file or database
//~ if(!empty($decodedData)){
	//~ file_put_contents('webhook.log', print_r($decodedData, true), FILE_APPEND);
//~ }

//~ //tkc_hubspot_webhook_data
//~ if(!empty($webhookData)){
	//~ save_tkc_option('hubspot_webhook_data', $webhookData);
//~ }

//~ $hubspot_webhook_data = get_tkc_option('hubspot_webhook_data');

//~ //echo "<pre>"; print_r($hubspot_webhook_data);
//~ //
//~ //echo "<pre>"; print_r(get_field('dealstage', 405));

//~ $decodedData = json_decode($hubspot_webhook_data, true);

//~ $dealsData = [$decodedData];

//~ //echo "<pre>"; print_r($dealsData);  echo "</pre>";

 //~ $deals = tkc_prepare_deals($dealsData);

//~ echo "<pre>"; print_r($deals);  echo "</pre>";

//~ tkc_create_post($deals);

//~ echo  "Deal Saved";

//~ exit;


// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Error logging function
function log_error($error_message) {
    file_put_contents('error.log', $error_message . PHP_EOL, FILE_APPEND);
}

require_once "../../../wp-load.php";


// Log the incoming request headers
$headers = getallheaders();
log_error("Request Headers: " . print_r($headers, true));

// Receive the webhook data
$webhookData = file_get_contents('php://input');
//~ if(empty($webhookData)) {
    //~ log_error('Webhook data is empty or not received.');
    //~ exit('No data received');
//~ }

$decodedData = json_decode($webhookData, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    log_error('JSON decoding error: ' . json_last_error_msg());
    //exit('Invalid JSON received');
}

// Log the raw data
//file_put_contents('webhook.log', "Raw webhook data: " . $webhookData . PHP_EOL, FILE_APPEND);
//file_put_contents('webhook11.log', print_r($_REQUEST, true), FILE_APPEND);

// Custom WordPress functions check
if (!function_exists('get_tkc_option')) {
    log_error('WordPress functions not available. Check wp-load.php.');
    exit('WordPress not loaded');
}

// Save the webhook data
if(!empty($webhookData)){
    save_tkc_option('hubspot_webhook_data', $webhookData);
}

$hubspot_webhook_data = get_tkc_option('hubspot_webhook_data');
if(empty($hubspot_webhook_data)) {
    log_error('Failed to retrieve hubspot_webhook_data from options.');
    exit('Failed to retrieve webhook data');
}

$decodedData = json_decode($hubspot_webhook_data, true);
$dealsData = [$decodedData];

// Prepare and save the deals
if(function_exists('tkc_prepare_deals') && function_exists('tkc_create_post')) {
    $deals = tkc_prepare_deals($dealsData);
    file_put_contents('webhook.log', "Prepared deals: " . print_r($deals, true) . PHP_EOL, FILE_APPEND);
    
    tkc_create_post($deals);
    
    echo "<pre>"; print_r($deals);  echo "</pre>";
    
    echo "Deal Saved";
} else {
    log_error('Required functions tkc_prepare_deals or tkc_create_post not found.');
    exit('Required functions missing');
}

exit;
