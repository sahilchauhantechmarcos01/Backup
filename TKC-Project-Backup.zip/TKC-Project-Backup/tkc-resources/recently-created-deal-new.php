<?php
require_once "../../../wp-load.php";

// recursively called till getting values in hasMore param
$dealsData = get_recently_created_deals();
//~ pr($dealsData);

// preapre deals to insert into DB
$deals = tkc_prepare_deals($dealsData);

//~ pr($deals);

echo "Total Deals: ";
echo count($deals);
echo "<br />";

echo "<pre>"; print_r($deals); echo "</pre>";

//create deals in the database
tkc_create_post($deals);

echo 'All Deal fetched & created -- NEW';

exit;
