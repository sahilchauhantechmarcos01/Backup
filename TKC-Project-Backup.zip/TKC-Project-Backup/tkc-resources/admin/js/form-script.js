(function ($) {
  $(function () {
})(jQuery);
