(function ($) {
  $("#tkcSaveHubSpotKeysForm").submit(function (e) {
    e.preventDefault();
    $.ajax({
      url: tkc_object.ajax_url, // this is the object instantiated in wp_localize_script function
      type: "POST",
      data: {
        action: "tkc_save_option", // this is the function in your functions.php that will be triggered
        hubspot_client_id: $("#hubspot_client_id").val(),
        hubspot_secret_key: $("#hubspot_secret_key").val(),
      },
      beforeSend: function () {
        $("#tkcSaveHubSpotKeys").val("Saving ....");
      },
      success: function (data) {
        //Do something with the result from server
        console.log(data);
        $("#tkcSaveHubSpotKeys").val("Save HubSpot Keys");
        $("#tkcKeysSaved").fadeIn();
        setTimeout(function () {
          $("#tkcKeysSaved").fadeOut();
        }, 3000);
        //$("#tkcSaveHubSpotKeys").hide();
      },
    });
  });

  $("#disconnectHs").click(function (e) {
    e.preventDefault();
    $.ajax({
      url: tkc_object.ajax_url, // this is the object instantiated in wp_localize_script function
      type: "POST",
      data: {
        action: "tkc_hs_disconnect", // this is the function in your functions.php that will be triggered
      },
      success: function (data) {
        //Do something with the result from server
        window.location.reload();
      },
    });
  });
  
   $("#tkcSaveHubSpotPortalIdForm").submit(function (e) {
    e.preventDefault();
    $.ajax({
      url: tkc_object.ajax_url, // this is the object instantiated in wp_localize_script function
      type: "POST",
      data: {
        action: "tkc_save_option", // this is the function in your functions.php that will be triggered
        hubspot_portal_id: $("#hubspot_portal_id").val()
      },
      beforeSend: function () {
        $("#tkcSaveHubSpotPortalId").val("Saving ....");
      },
      success: function (data) {
        //Do something with the result from server
        console.log(data);
        $("#tkcSaveHubSpotPortalId").val("Save HubSpot Portal ID");
        $("#tkcSaveHubSpotPortalIdSaved").fadeIn();
        setTimeout(function () {
          $("#tkcSaveHubSpotPortalIdSaved").fadeOut();
        }, 3000);
        //$("#tkcSaveHubSpotKeys").hide();
      },
    });
  });
  
})(jQuery);
