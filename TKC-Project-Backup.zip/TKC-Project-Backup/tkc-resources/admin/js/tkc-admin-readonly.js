(function ($) {
  $("#title").attr("readonly", "readonly");
  $("#title").prop("disabled", true);

  var acf_field_mapping = [
    "hs_object_id",
    "dealname",
    "dealstage",
    "property_name",
    "property_address",
    "property_city",
    "property_state",
	"property_zip",  
    "year_built",
    "number_of_units",
  ];

  $.each(acf_field_mapping, function (ind, field_name) {
    $('[data-name="' + field_name + '"] input').attr("readonly", "readonly");
    $('[data-name="' + field_name + '"]  input').prop("disabled", true);
  });

  $('[data-name="division"] select').attr("readonly", "readonly");
  $('[data-name="division"]  select').prop("disabled", true);
})(jQuery);
