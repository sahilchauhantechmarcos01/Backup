<?php

$hubspot_client_id = get_tkc_option('hubspot_client_id');
$hubspot_secret_key = get_tkc_option('hubspot_secret_key');
$hubspot_refresh_token = get_tkc_option('hubspot_refresh_token');

$scopes = [
    'oauth',
    'crm.objects.contacts.read',
    //'crm.objects.contacts.write',
    'crm.schemas.contacts.read',
    'crm.objects.deals.read',
    'crm.schemas.deals.read',
    'cms.domains.read',
    //'crm.objects.companies.read',
    //'crm.schemas.companies.read',
    //'crm.schemas.contacts.write'
];

$scope_string = implode('%20', $scopes);
$redirect_url = TKC_URL . "hubspot-connect.php";

$init_url = 'https://app.hubspot.com/oauth/authorize?client_id=' . $hubspot_client_id . '&redirect_uri=' . $redirect_url . '&scope=' . $scope_string; ?>
<div class="wrap">
    <h2>HubSpot Integration Settings</h2>
    <form method="post" action="javascript:void(0);" id="tkcSaveHubSpotKeysForm">
        <p>Enter your HubSpot integration details below:</p>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">HubSpot Client ID</th>
                    <td>
                        <input type="text" class="tkc-auto-save" id="hubspot_client_id" name="hubspot_client_id" value="<?= $hubspot_client_id ?? ''; ?>" <?php if (!empty($hubspot_refresh_token)) { ?> readonly="readonly" <?php } ?>>
                    </td>
                </tr>
                <tr>
                    <th scope="row">HubSpot Secret Key</th>
                    <td>
                        <input type="text" id="hubspot_secret_key" name="hubspot_secret_key" value="<?= $hubspot_secret_key ?? ''; ?>" <?php if (!empty($hubspot_refresh_token)) { ?> readonly="readonly" <?php } ?>>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <?php if (empty($hubspot_refresh_token)) { ?>
            <input type="submit" id="tkcSaveHubSpotKeys" class="button action" value="Save HubSpot Keys">
        <?php } ?>
        <h4 class="" style="display:none; color:green" id="tkcKeysSaved">Saved Successfully</h4>
    </form>
    <br />
    <hr />
    <br />

    <?php if (empty($hubspot_refresh_token)) { ?>
        <h3>Connect to HubSpot</h3>
        <p><b>Redirect URL:</b> <?= $redirect_url; ?></p>
        <p><b>Create a private app and add folowing Scopes:</b></p>
        <ul style="margin-left: 200px;">
            <?php foreach ($scopes as $scope) { ?>
                <li><?= $scope; ?></li>
            <?php } ?>
        </ul>
        <a href="<?= $init_url; ?>"><input type="button" id="tkcHubSpotConnect" class="button action" value="Connect to HubSpot"></a>
    <?php } else { ?>
        <?php
        $hubspot_connected_account = get_tkc_option('hubspot_connected_account'); ?>

        <h3>Connected to HubSpot</h3>
        <p><b>Connected Account:</b> <?= $hubspot_connected_account; ?></p>
        <a href="javascript:void(0);"><input type="button" id="disconnectHs" class="button action" value="Disconnect HubSpot"></a>
    <?php } ?>
</div>