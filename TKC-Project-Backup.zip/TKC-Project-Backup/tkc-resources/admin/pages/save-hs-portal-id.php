<?php
$hubspot_portal_id = get_tkc_option('hubspot_portal_id');
?>
<div class="wrap">
    <h2>HubSpot Portal ID</h2>
    <form method="post" action="javascript:void(0);" id="tkcSaveHubSpotPortalIdForm">
        <p>Enter your HubSpot Portal ID:</p>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">HubSpot Portal ID</th>
                    <td>
                        <input type="text" class="tkc-auto-save" id="hubspot_portal_id" name="hubspot_portal_id" value="<?= $hubspot_portal_id ?? ''; ?>" />
                    </td>
                </tr>

            </tbody>
        </table>
        <input type="submit" id="tkcSaveHubSpotPortalId" class="button action" value="Save HubSpot Portal ID">
        <h4 class="" style="display:none; color:green" id="tkcSaveHubSpotPortalIdSaved">Saved Successfully</h4>
    </form>

</div>