<div class="wrap">
    <h2>Required Plugins - Live</h2>
    <?php if (!class_exists('ACF')) { ?>

        <p><?php printf(
                wp_kses(
                    __('The <strong>TKC Resources</strong> plugin requires <a href="%1$s" target="_blank" rel="noopener noreferrer">ACF Plugin</a>. You can disable and uninstall it on the <a href="%2$s">plugins page</a>.', 'tkc-resources'),
                    ['strong' => [], 'a'    => ['href' => [], 'target' => [], 'rel' => '']]
                ),
                esc_url('https://www.advancedcustomfields.com/'),
                esc_url(admin_url('plugins.php'))
            ); ?></p>

    <?php } else { ?>

        <h4><b>ACF:</b> Installed <i class="fa fa-check"></i></h4>

    <?php } ?>

</div>
