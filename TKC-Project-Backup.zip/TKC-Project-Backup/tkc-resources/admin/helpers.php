<?php
// In your main plugin file (my-plugin.php)
function tkc_scripts() {
    wp_enqueue_script('jquery');


    if(isset( $_GET['post'] ) && get_post_type() == 'rentcomps'){
        wp_enqueue_script('tkc-admin-script', TKC_URL . 'admin/js/tkc-admin-readonly.js', array('jquery'), '1.1', true);
    }


    
    wp_enqueue_script('tkc-admin-script', TKC_URL . 'admin/js/tkc-admin-script.js', array('jquery'), '1.1', true);

    wp_localize_script('tkc-admin-script', 'tkc_object', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('admin_enqueue_scripts', 'tkc_scripts');
