<?php
function save_tkc_option($name, $value) {
    (get_option(TKC_ . $name) !== false)  ? update_option(TKC_ . $name, $value)  : add_option(TKC_ . $name, $value);
}

function get_tkc_option($name) {
    return get_option(TKC_ . $name);
}

add_action('wp_ajax_tkc_save_option', 'tkc_save_option');

function tkc_save_option() {

    foreach ($_POST as $name => $value) {
        switch ($name) {
			case 'hubspot_portal_id':
            case 'hubspot_client_id':
            case 'hubspot_secret_key':
            case 'hubspot_refresh_token': {
                    save_tkc_option($name, $value);
                    break;
                }
        }
    }

    return json_encode(['status' => 'updated']);
}
