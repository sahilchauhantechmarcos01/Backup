<?php
// Hook into the admin menu to create a top-level menu
add_action('admin_menu', 'hubspot_integration_menu');

// Function to create the top-level menu page
function hubspot_integration_menu() {
    add_menu_page(
        'TKC', // Page title
        'TKC', // Menu title
        'manage_options', // Capability
        'hubspot-main-menu', // Menu slug
        'hubspot_settings_page', // Callback function
        'dashicons-admin-plugins' // Icon
    );

    // Add sub-menu items
    add_submenu_page(
        'hubspot-main-menu', // Parent menu slug
        'Installation', // Page title
        'Installation', // Menu title
        'manage_options', // Capability
        'hubspot-installations', // Menu slug
        'hubspot_installations_page' // Callback function
    );
    
    // Add sub-menu items
    add_submenu_page(
        'hubspot-main-menu', // Parent menu slug
        'HS Portal ID', // Page title
        'HS Portal ID', // Menu title
        'manage_options', // Capability
        'hubspot-portal-id', // Menu slug
        'hubspot_portal_id_page' // Callback function
    );

    add_submenu_page(
        'hubspot-main-menu', // Parent menu slug
        'Settings', // Page title
        'Settings', // Menu title
        'manage_options', // Capability
        'hubspot-settings', // Menu slug
        'hubspot_settings_page' // Callback function
    );
}



// Callback function for the main menu page
function hubspot_main_menu_page() {
    include 'pages/settings.php';
}

// Callback function for the "Deals" sub-menu page
function hubspot_installations_page() {
    include 'pages/installations.php';
}

// Callback function for the "Deals" sub-menu page
function hubspot_portal_id_page() {
    include 'pages/save-hs-portal-id.php';
}

// Callback function for the "Settings" sub-menu page
function hubspot_settings_page() {
    include 'pages/settings.php';
}
