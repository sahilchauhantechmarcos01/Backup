<?php
/*
Plugin Name: TKC
Description: Manage Deals from the HubSpot with ACF Pro Dependancy.
Version: 1.0
Author: Your Name
*/

if (!defined('ABSPATH')) {
	die('Invalid request.');
}

if (!defined('TKC')) {
	define('TKC', 'tkc'); // Plugin Prefix without underscore- SpotOnCare Bookings
}

if (!defined('TKC_')) {
	define('TKC_', 'tkc_'); // Plugin Prefix with underscore - SpotOnCare Bookings
}

if (!defined('TKC_DIR')) {
	define('TKC_DIR', plugin_dir_path(__FILE__));
}
if (!defined('TKC_SLUG')) {
	define('TKC_SLUG', 'tkc-plugin');
}
if (!defined('TKC_VERSION')) {
	define('TKC_VERSION', '1.0.6');
}
if (!defined('TKC_URL')) {
	define('TKC_URL', plugins_url('/', __FILE__));
}

if (!defined('TKC_DEBUG')) {
	define('TKC_DEBUG', false);
}

//pr();



function tkc_load_files() {
	if (is_admin()) {
		require_once(TKC_DIR . 'admin/helpers.php');
		require_once(TKC_DIR . 'admin/menu.php');

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	} else {
		function tkc_frontend_script() {
			// Enqueue the script with a unique handle, path to the file, and any dependencies.
			wp_enqueue_script('tkc-front-script', TKC_URL . 'public/js/scripts.js', array('jquery'), TKC_VERSION, true);
			wp_enqueue_style('main-styles', TKC_URL . 'public/css/style.css', array(), filemtime(TKC_URL . 'public/css/style.css'), false);
			wp_localize_script('tkc-front-script', 'tkc_object', array('ajax_url' => admin_url('admin-ajax.php')));
		}
		add_action('wp_enqueue_scripts', 'tkc_frontend_script');
	}

	require_once(TKC_DIR . 'admin/includes/options.php');
	require_once(TKC_DIR . 'includes/hubspot.php');
	require_once(TKC_DIR .  'tck-download-pdf.php');
	require_once(TKC_DIR .  'tck-download-xlsx.php');

	if (!class_exists('ACF')) {
		if (
			isset($_REQUEST['page'])
			&& $_REQUEST['page'] !== "hubspot-installations"
			&& in_array($_REQUEST['page'], ['hubspot-main-menu', 'hubspot-settings'])
		) {
			wp_redirect("admin.php?page=hubspot-installations");
		}
		//	
	}
}
add_action('init', 'tkc_load_files');

// function fetch_hubspot_data() {
//     $options = get_option('hubspot_integration');
// }

// fetch_hubspot_data();



register_uninstall_hook(__FILE__, 'tkc_cleanup');

function tkc_cleanup() {
	save_tkc_option('hubspot_connected_account', "");
	save_tkc_option('hubspot_refresh_token', "");
	save_tkc_option('hubspot_all_deal_offset', '0');
	save_tkc_option('hubspot_recently_created_deal_offset', '0');
	save_tkc_option('hubspot_recently_modified_deal_offset', '0');
}

add_filter( 'theme_page_templates', 'sf_add_page_template_to_dropdown' );
/**
* Add page templates.
*
* @param  array  $templates  The list of page templates
*
* @return array  $templates  The modified list of page templates
*/
function sf_add_page_template_to_dropdown( $templates )
{
   $templates[plugin_dir_path( __FILE__ ) . 'templates/page-template.php'] = __( 'TKC Template From TKC Plugin', 'text-domain' );
   return $templates;
}
add_filter( 'template_include', 'pt_change_page_template', 99 );
/**
 * Change the page template to the selected template on the dropdown
 * 
 * @param $template
 *
 * @return mixed
 */
function pt_change_page_template($template)
{
	$tempPath =  get_post_meta(get_the_ID(),'_wp_page_template',true);
    if (!is_front_page() && !is_page_template('default') && str_contains($tempPath, 'page-template.php')) {
        $meta = get_post_meta(get_the_ID());
        if (!empty($meta['_wp_page_template'][0]) && $meta['_wp_page_template'][0] != $template) {
            $template = $meta['_wp_page_template'][0];
        }
    }
    return $template;
}
// registered new image size to use in the export pdf
add_image_size( 'export-pdf', 457, 420 ); 



function custom_shortcode_to_print_buttons() {
    return'<li><a href="javascript:void(0);" id="tkcDownloadHorizontalPdf">Horizontal Export</a></li>
		<li><a href="javascript:void(0);" id="tkcDownloadVerticalPdf">Vertical Export</a></li>
		<li><a href="javascript:void(0);" id="tkcDownloadXlsx">Export to XLSX</a></li>
		<div id="myModal" class="modal">
			<div class="modal-content">
				<span class="close divclose" id="closeModal">X</span>
				<form id="myForm">
					<label for="url">Image Base Url:</label>
					<input type="text" id="url" name="url">
					<input type="button" class="sumit-button" id="hit" value="Update"/>
				</form>
			</div>
		</div>';
}
add_shortcode('export_buttons', 'custom_shortcode_to_print_buttons');

function add_custom_button_meta_box() {
    add_meta_box(
        'custom_button_meta_box',       // ID of the meta box
        'Sync data with Hubspot',                // Title of the meta box
        'custom_button_meta_box_callback', // Callback function
        'rentcomps',        // Custom post type slug
        'side',                         // Position (side or normal)
        'high'                          // Priority
    );
}
add_action('add_meta_boxes', 'add_custom_button_meta_box');

function custom_button_meta_box_callback($post) {
	$post_id = $post->ID;
    //$custom_url = esc_url('https://tkcresources.wpengine.com/wp-content/plugins/tkc-resources/recently-modified-deal.php?pi='.$post_id); // Custom URL
	if ($post->post_status === 'publish') { ?>
		<div style="display: flex;
  align-items: center;
  gap: 10px;">
		<a href="#" class="button button-primary button-large" onclick="reloadAndClose(<?php echo $post_id; ?>); return false;"> Sync 
		</a>
		<span  id="hs-sync-loader" style="display: none;">
			<img src="images/spinner.gif" />
		</span>
		</div>
		<?php
	}	
}

function custom_admin_enqueue_scripts($hook) {
		// Only enqueue the script on the post edit screen
		if ($hook === 'post.php' && isset($_GET['post'])) {
			$post_id = $_GET['post'];
			
			// Enqueue the JavaScript file
			wp_enqueue_script('custom-plugin-admin-ajax-script', plugin_dir_url(__FILE__) . 'public/js/custom-button.js', array('jquery'), null, true);
	
			// Localize the script to pass the URL with post ID
			wp_localize_script('custom-plugin-admin-ajax-script', 'ajax_object', array(
				'background_url' => 'https://tkcresources.wpengine.com/wp-content/plugins/tkc-resources/recently-modified-deal-new.php?pi=' . $post_id
			));
		}
}
add_action('admin_enqueue_scripts', 'custom_admin_enqueue_scripts');

/************* CUstom Box to show last updated and modified time - Starts ****************/
function lollisoda_add_last_modified_meta_box() {
    add_meta_box(
        'lollisoda_last_modified',
        'Last Modified At',
        'lollisoda_last_modified_callback',
        'rentcomps',
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'lollisoda_add_last_modified_meta_box');

function lollisoda_last_modified_callback($post) {
    $last_user_id = get_post_meta($post->ID, '_edit_last', true);
    if ($last_user_id) {
        $last_user = get_userdata($last_user_id);
        $last_modified = get_post_modified_time('F j, Y g:i a', false, $post->ID);
        echo '<p><strong>Last Updated by:</strong> ' . esc_html($last_user->display_name) . '</p>';
        echo '<p><strong>On:</strong> ' . esc_html($last_modified) . '</p>';
    } else {
        echo '<p>No edit history available.</p>';
    }
}
/************* CUstom Box to show last updated and modified time - Ends ****************/
/******************* Manuaaly Run Cron Button ******************************/
function add_cron_button_admin_page() {
    $screen = get_current_screen();

    // Check if we're on the Rent-Com listing page (change post type if needed)
    if ($screen->post_type !== 'rentcomps') {
        return;
    }

    echo '
    <div class="cron-job-container" style="float: right; margin-top: 1px;">
        <button id="run-cron-job" class="button button-primary">Run HubSpot Sync</button>
    </div>';
}
add_action('admin_notices', 'add_cron_button_admin_page');

function enqueue_admin_cron_script($hook) {
    $screen = get_current_screen();
    if ($screen->post_type !== 'rentcomps') {
        return;
    }

	// Enqueue the JavaScript file
	wp_enqueue_script('cron-ajax-script', plugin_dir_url(__FILE__) . 'public/js/cron-script.js', array('jquery'), null, true);
        wp_localize_script('cron-ajax-script', 'cron_ajax_object', array(
		'ajax_url' => admin_url('admin-ajax.php'),
		'cron_urls' => array(
			'recently_created' => site_url('/wp-content/plugins/tkc-resources/recently-created-deal-new.php'),
			'recently_modified' => site_url('/wp-content/plugins/tkc-resources/recently-modified-deal-new.php'),
			'recently_deleted' => site_url('/wp-content/plugins/tkc-resources/tck-delete.php'),
		)
	));

}
add_action('admin_enqueue_scripts', 'enqueue_admin_cron_script');



// Rentcomps Admin Filters
/*
add_action('restrict_manage_posts', function($post_type){
    if ($post_type !== 'rentcomps') {
        return;
    }

    global $wpdb;

    // Get unique states (skip empty)
    $states = $wpdb->get_col("
        SELECT DISTINCT pm.meta_value
        FROM {$wpdb->postmeta} pm
        INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
        WHERE pm.meta_key = 'property_state'
        AND pm.meta_value != ''
        AND p.post_type = 'rentcomps'
        AND p.post_status = 'publish'
        ORDER BY pm.meta_value ASC
    ");

    // Get unique cities (skip empty)
    $cities = $wpdb->get_col("
        SELECT DISTINCT pm.meta_value
        FROM {$wpdb->postmeta} pm
        INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
        WHERE pm.meta_key = 'property_city'
        AND pm.meta_value != ''
        AND p.post_type = 'rentcomps'
        AND p.post_status = 'publish'
        ORDER BY pm.meta_value ASC
    ");

    // Current selected values
    $current_state = isset($_GET['property_state']) ? $_GET['property_state'] : '';
    $current_city  = isset($_GET['property_city']) ? $_GET['property_city'] : '';

    // State Dropdown
    echo '<select name="property_state" id="property_state" style="min-width:200px;">';
    echo '<option value="">All States</option>';
    foreach ($states as $state) {
        printf(
            '<option value="%s" %s>%s</option>',
            esc_attr($state),
            selected($current_state, $state, false),
            esc_html($state)
        );
    }
    echo '</select>';

    // City Dropdown (searchable with select2)
    echo '<select name="property_city" id="property_city" style="min-width:250px;">';
    echo '<option value="">All Cities</option>';
    foreach ($cities as $city) {
        printf(
            '<option value="%s" %s>%s</option>',
            esc_attr($city),
            selected($current_city, $city, false),
            esc_html($city)
        );
    }
    echo '</select>';
});

add_action('pre_get_posts', function($query){
    global $pagenow;

    if (
        is_admin() &&
        $pagenow == 'edit.php' &&
        $query->get('post_type') === 'rentcomps'
    ) {
        $meta_query = [];

        if (!empty($_GET['property_state'])) {
            $meta_query[] = [
                'key'   => 'property_state',
                'value' => sanitize_text_field($_GET['property_state'])
            ];
        }

        if (!empty($_GET['property_city'])) {
            $meta_query[] = [
                'key'   => 'property_city',
                'value' => sanitize_text_field($_GET['property_city'])
            ];
        }

        if (!empty($meta_query)) {
            $query->set('meta_query', $meta_query);
        }
    }
});

add_action('admin_enqueue_scripts', function($hook){
    global $typenow;
    if ($typenow === 'rentcomps' && $hook === 'edit.php') {
        // Load select2 from WP core (comes bundled)
        wp_enqueue_script('select2');
        wp_enqueue_style('select2');

        // Init select2
        add_action('admin_footer', function(){
            ?>
            <script>
            jQuery(document).ready(function($){
                $('#property_state').select2({ placeholder: "Select State", allowClear: true });
                $('#property_city').select2({ placeholder: "Select City", allowClear: true });
            });
            </script>
            <?php
        });
    }
});
*/
