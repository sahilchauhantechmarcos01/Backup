<?php
require_once "../../../wp-load.php";

$endpoint = 'https://api.hubapi.com/crm/v3/objects/deals?limit=100&archived=true';

$dealIds = get_recently_deleted_deals($endpoint);

// Ensure the deal IDs are formatted correctly for SQL (use %d for integers)
$placeholders = implode(',', array_fill(0, count($dealIds), '%d'));

// Initialize the base query
$query = "SELECT posts.id, post_meta.meta_value
    FROM $wpdb->postmeta AS post_meta
    JOIN $wpdb->posts AS posts ON post_meta.post_id = posts.ID
    WHERE post_meta.meta_key = 'hs_object_id'
    AND posts.post_type = 'rentcomps'
    AND post_meta.meta_value IN ($placeholders)
    AND posts.post_status = 'publish'
";
// AND post_meta.meta_key NOT LIKE 'rent_comps_'
// Prepare and execute the query
$query = $wpdb->prepare($query, ...$dealIds);
$existing_deal_ids = $wpdb->get_results($query);

// Print the results to debug
if(!empty($existing_deal_ids)){
    foreach($existing_deal_ids as $post){
        wp_trash_post($post->id); //soft delete
        check_if_deal_used_in_pages($post->id);
        file_put_contents('deleteDeal.log', "Delete post: " . print_r($post, true) . PHP_EOL, FILE_APPEND);
        echo "Post ID $post->id its meta have been deleted." . '<br/>';
    }
}

function check_if_deal_used_in_pages($id){
    global $wpdb;
    $query = $wpdb->prepare(
        "SELECT post_meta.meta_key, post_meta.meta_value 
         FROM $wpdb->postmeta AS post_meta 
         WHERE post_meta.meta_key LIKE %s 
         AND post_meta.post_id = %d", 
        '%rent_comps_%', // The LIKE pattern
        $id             // The post ID
    );
    $metaDetails = $wpdb->get_results($query); 
    if ($metaDetails) {
        foreach ($metaDetails as $meta) {
            $meta_key = $meta->meta_key;
            delete_post_meta( $id, $meta_key);
        }
    }
}

?>