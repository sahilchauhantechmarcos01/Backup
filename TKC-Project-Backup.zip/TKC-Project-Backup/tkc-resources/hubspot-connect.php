<?php
require_once "../../../wp-load.php";

tkc_get_hs_response($_REQUEST['code']);

wp_redirect(admin_url('/admin.php?page=hubspot-settings'));
exit;
