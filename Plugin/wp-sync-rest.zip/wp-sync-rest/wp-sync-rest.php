<?php 
/*
Plugin Name: WP-Sync-Rest
Plugin URI: https://wordpress.com
Description: Sync Posts and Pages 
Version: 1.0.0
Requires PHP: 7.2
Author: DB01
License:  GPL v2 or later
Text Domain: wp-sync-rest
*/

defined('ABSPATH') or die('Not acccessible');


class sync{
    public $key = '';
    public $myallposts = array();
    function __construct(){
     $this->create_key();
     add_action('admin_enqueue_scripts', [$this,'sync_admin_styles']);
     add_action('admin_menu', [$this, 'plugin_admin_menu']);
     $this->create_endpoint();
    }
    function sync_admin_styles($hook) {
if (strpos($hook, 'wp-sync-rest') === false) {
    return;
}
    wp_enqueue_style(
        'sync-admin-style',
        plugin_dir_url(__FILE__) . 'style.css'
    );
      wp_enqueue_script(
        'sync-admin-script',
        plugin_dir_url(__FILE__) . 'main.js',
        [],              
        false,           
        true              
    );
    $key = get_option('wp_sync_rest_key');
    $url = home_url();
    $myallpostsItems = $this->getMyPosts();
   wp_localize_script('sync-admin-script', 'syncData', [
    'api_key' => $key,
    'home_url' => $url,
    'myallpostsItems' => $myallpostsItems,
]);
}
function create_key(){
    $this->key = get_option('wp_sync_rest_key');
if (!$this->key) {
     $this->key = bin2hex(random_bytes(16)); 
    update_option('wp_sync_rest_key',  $this->key);
}

}
function create_endpoint(){
   add_action('rest_api_init', function(){
   register_rest_route(
    'sync-api/v1',
    '/setall',
    [
        'permission_callback' => function(WP_REST_Request $request){
            return true;
        },
        'methods' => 'POST',
        'callback' => function(WP_REST_Request $request){
             $body = json_decode($request->get_body());
             return $this->do_api_action($body);
        }
    ]
   );
   register_rest_route(
    'sync-api/v1',
    '/setpages',
    [
        'permission_callback' => function(WP_REST_Request $request){
            return true;
        },
        'methods' => 'POST',
        'callback' => function(WP_REST_Request $request){
             $body = json_decode($request->get_body());
             return $this->do_api_action_pages($body);
        }
    ]
   );
      register_rest_route(
    'sync-api/v1',
    '/setposts',
    [
        'permission_callback' => function(WP_REST_Request $request){
            return true;
        },
        'methods' => 'POST',
        'callback' => function(WP_REST_Request $request){
             $body = json_decode($request->get_body());
             return $this->do_api_action_posts($body);
        }
    ]
   );
      register_rest_route(
    'sync-api/v1',
    '/customSet',
    [
        'permission_callback' => function(WP_REST_Request $request){
            return true;
        },
        'methods' => 'POST',
        'callback' => function(WP_REST_Request $request){
             $body = json_decode($request->get_body());
             return $this->do_api_action_custom($body);
        }
    ]
   );
      register_rest_route(
    'sync-api/v1',
    '/setwebsitedata',
    [
        'permission_callback' => function(WP_REST_Request $request){
            return true;
        },
        'methods' => 'POST',
        'callback' => function(WP_REST_Request $request){
             $body = json_decode($request->get_body());
             return $this->websiteListData($body);
        }
    ]
   );
      register_rest_route(
    'sync-api/v1',
    '/getwebsitedata',
    [
        'permission_callback' => function(WP_REST_Request $request){
            return true;
        },
        'methods' => 'GET',
        'callback' => function(WP_REST_Request $request){
             return $this->get_sites_list();
        }
    ]
   );
      register_rest_route(
    'sync-api/v1',
    '/deletesite',
    [
        'permission_callback' => function(WP_REST_Request $request){
            return true;
        },
        'methods' => 'POST',
        'callback' => function(WP_REST_Request $request){
            $body = json_decode($request->get_body());
             return $this->delete_site($body);
        }
    ]
   );
      register_rest_route(
    'sync-api/v1',
    '/syncData',
    [
        'permission_callback' => function(WP_REST_Request $request){
            return true;
        },
        'methods' => 'POST',
        'callback' => function(WP_REST_Request $request){
            $body = json_decode($request->get_body());
             return $this->sync_data($body);
        }
    ]
   );
   });
}
function sync_data($body){
    if(!isset($body->key) || $body->key !== $this->key){
        return new WP_REST_Response(['error' => 'Invalid key'], 403);
    }
    $post_type = ($body->postType === 'any') ? 'any' : sanitize_text_field($body->postType);
        $args = array(
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => $body->size, 
            'fields' => 'all', 
        );
        if($body->category !== 'all'){
         $args['category_name'] = $body->category;
         }
        
        $query = new WP_Query($args);
        $all_posts = array();
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                global $post;
                $post_data = array(
                    'id' => $post->ID,
                    'date' => $post->post_date,
                    'date_gmt' => $post->post_date_gmt,
                    'modified' => $post->post_modified,
                    'modified_gmt' => $post->post_modified_gmt,
                    'slug' => $post->post_name,
                    'status' => $post->post_status,
                    'type' => $post->post_type,
                    'link' => get_permalink($post->ID),
                    'title' => array(
                        'rendered' => get_the_title($post->ID)
                    ),
                    'content' => array(
                        'rendered' => get_the_content(null, false, $post->ID),
                        'protected' => false
                    ),
                    'excerpt' => array(
                        'rendered' => get_the_excerpt($post->ID),
                        'protected' => false
                    ),
                    'author' => (int) $post->post_author,
                    'featured_media' => (int) get_post_thumbnail_id($post->ID),
                    'comment_status' => $post->comment_status,
                    'ping_status' => $post->ping_status,
                    'sticky' => is_sticky($post->ID),
                    'template' => get_page_template_slug($post->ID),
                    'format' => get_post_format($post->ID) ?: 'standard',
                    'meta' => array(),
                    'categories' => wp_get_post_categories($post->ID, array('fields' => 'ids')),
                    'tags' => wp_get_post_tags($post->ID, array('fields' => 'ids')),
                );
                
                $all_posts[] = $post_data;
            }
            wp_reset_postdata();
        } 
        $senderPosts = $body->myallpostsItems;
        $senderPosts = json_decode(json_encode($senderPosts), true);

        // $resultArray = array_merge($senderPosts , $all_posts);
        // $uniquePosts =  array_unique($resultArray);
        //   wp_insert_post( $uniquePosts,$wp_error = false );
foreach ($senderPosts as $remote_post) {
     $messageRes = 'Starting';
    //  $messageRes .= "Post type : $post_type | " . $remote_post['type'] . "\n";
    //  $messageRes .= "Category : $body->category | " . implode(', ', $remote_post['categories']) . "\n"; 

    if($post_type !== 'any' && $remote_post['type'] != $post_type) continue;
    $catNotInclude = false;
    foreach($remote_post['categories'] as $key => $val){
        if($val != $body->category ) $catNotInclude = true;
    }
    if($catNotInclude) continue;
   
    $taxonomyz = $body->taxonomy_name ?? '';

if (!empty($taxonomyz) && $taxonomyz !== 'all') {
    $postTaxonomies = $remote_post['taxonomies'] ?? [];
    
    if (!isset($postTaxonomies[$taxonomyz]) || !is_array($postTaxonomies[$taxonomyz]) || count($postTaxonomies[$taxonomyz]) === 0) {
        continue; 
    }
}


    $messageRes .= 'End';
    $existing = get_page_by_path($remote_post['slug'], OBJECT, $remote_post['type']);

    $postarr = [
        'post_title'       => $remote_post['title']['rendered'],
        'post_name'        => $remote_post['slug'],
        'post_status'      => $remote_post['status'],
        'post_type'        => $remote_post['type'],
        'post_content'     => $remote_post['content']['rendered'],
        'post_excerpt'     => $remote_post['excerpt']['rendered'],
        'post_author'      => $remote_post['author'],
        'comment_status'   => $remote_post['comment_status'],
        'ping_status'      => $remote_post['ping_status'],
        'post_date'        => $remote_post['date'],
        'post_date_gmt'    => $remote_post['date_gmt'],
        'post_modified'    => $remote_post['modified'],
        'post_modified_gmt'=> $remote_post['modified_gmt'],
    ];

    if ($existing) {
        $postarr['ID'] = $existing->ID;
        $post_id = wp_update_post($postarr);
    } else {
        $post_id = wp_insert_post($postarr);
    }

    if (is_wp_error($post_id)) continue;

    if (!empty($remote_post['categories'])) {
        wp_set_post_categories($post_id, $remote_post['categories']);
    }

    if (!empty($remote_post['tags'])) {
        wp_set_post_tags($post_id, $remote_post['tags']);
    }


    if (!empty($remote_post['featured_media'])) {
        set_post_thumbnail($post_id, $remote_post['featured_media']);
    }

 
    if (!empty($remote_post['format'])) {
        set_post_format($post_id, $remote_post['format']);
    }

  
    if (!empty($remote_post['template'])) {
        update_post_meta($post_id, '_wp_page_template', $remote_post['template']);
    }


    if (!empty($remote_post['sticky'])) {
        stick_post($post_id);
    } else {
        unstick_post($post_id);
    }


    if (!empty($remote_post['meta'])) {
        foreach ($remote_post['meta'] as $key => $value) {
            // If value is array, store first — matches wp core REST output
            if (is_array($value)) $value = reset($value);
            update_post_meta($post_id, $key, $value);
        }
    }
        if (!empty($remote_post['taxonomies'])) {
        foreach ($remote_post['taxonomies'] as $taxonomy => $term_ids) {
            if (!taxonomy_exists($taxonomy)) continue; // prevent errors
            wp_set_object_terms($post_id, $term_ids, $taxonomy);
        }
    }

    
}


        return [
    'received' => count($senderPosts),
    'posts'    => $all_posts,
    'message'   => $messageRes,
];
    
    
    return new WP_REST_Response(['error' => 'Invalid type parameter'], 400);
}
function delete_site($body) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'weblist';

    // Sanitize inputs
    $site_key = $body->site_key;
    $site_url = $body->site_url;

    // Delete the row
    $deleted = $wpdb->delete(
        $table_name,
        [
            'site_key' => $site_key,
            'site_url' => $site_url
        ],
        ['%s', '%s']
    );
}

function get_sites_list() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'weblist';
    $results = $wpdb->get_results("SELECT site_key, site_url FROM $table_name", ARRAY_A);

    $sites = [];
    if ($results) {
        foreach ($results as $row) {
            $sites[] = [$row['site_key'], $row['site_url']];
        }
    }

    return $sites;
}

function websiteListData($body){
    global  $wpdb;
    $table_name = $wpdb->prefix . 'weblist';
    $charset_collate = $wpdb->get_charset_collate();

    if(!$wpdb->get_var("SHOW TABLES LIKE '$table_name'")){
        $sql = "
        CREATE TABLE $table_name (
            id INT NOT NULL AUTO_INCREMENT,
            site_key VARCHAR(255),
            site_url VARCHAR(255),
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    if (!empty($body->site_key) && !empty($body->site_url)) {

        $site_key = sanitize_text_field($body->site_key);
        $site_url  = esc_url_raw($body->site_url);

        $wpdb->insert(
            $table_name,
            [
                'site_key' => $site_key,
                'site_url'  => $site_url
            ],
            ['%s', '%s']
        );

        return [
            'success' => true,
            'message' => 'Site added successfully'
        ];
    }

    return [
        'success' => false,
        'message' => 'Missing site_name or site_url'
    ];
}


function do_api_action_custom($body){
    if(!isset($body->key) || $body->key !== $this->key){
        return new WP_REST_Response(['error' => 'Invalid key'], 403);
    }

    if($body->custom_type === 'post'  ){     // && post_type_exists( $body->type )
    if($body->custom_type === 'post') {
        $args = array(
            'post_type' => $body->type,
            'post_status' => 'publish',
            'posts_per_page' => -1, 
            'fields' => 'all', 
        );
        
        $query = new WP_Query($args);
        $all_posts = array();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                global $post;
                $post_data = array(
                    'id' => $post->ID,
                    'date' => $post->post_date,
                    'date_gmt' => $post->post_date_gmt,
                    'modified' => $post->post_modified,
                    'modified_gmt' => $post->post_modified_gmt,
                    'slug' => $post->post_name,
                    'status' => $post->post_status,
                    'type' => $post->post_type,
                    'link' => get_permalink($post->ID),
                    'title' => array(
                        'rendered' => get_the_title($post->ID)
                    ),
                    'content' => array(
                        'rendered' => get_the_content(null, false, $post->ID),
                        'protected' => false
                    ),
                    'excerpt' => array(
                        'rendered' => get_the_excerpt($post->ID),
                        'protected' => false
                    ),
                    'author' => (int) $post->post_author,
                    'featured_media' => (int) get_post_thumbnail_id($post->ID),
                    'comment_status' => $post->comment_status,
                    'ping_status' => $post->ping_status,
                    'sticky' => is_sticky($post->ID),
                    'template' => get_page_template_slug($post->ID),
                    'format' => get_post_format($post->ID) ?: 'standard',
                    'meta' => array(),
                    'categories' => wp_get_post_categories($post->ID, array('fields' => 'ids')),
                    'tags' => wp_get_post_tags($post->ID, array('fields' => 'ids')),
                );
                
                $all_posts[] = $post_data;
            }
            wp_reset_postdata();
        } 
        $senderPosts = $body->myallpostsItems;
        $senderPosts = json_decode(json_encode($senderPosts), true);

        // $resultArray = array_merge($senderPosts , $all_posts);
        // $uniquePosts =  array_unique($resultArray);
        //   wp_insert_post( $uniquePosts,$wp_error = false );
foreach ($senderPosts as $remote_post) {

    $existing = get_page_by_path($remote_post['slug'], OBJECT, $remote_post['type']);

    $postarr = [
        'post_title'       => $remote_post['title']['rendered'],
        'post_name'        => $remote_post['slug'],
        'post_status'      => $remote_post['status'],
        'post_type'        => $remote_post['type'],
        'post_content'     => $remote_post['content']['rendered'],
        'post_excerpt'     => $remote_post['excerpt']['rendered'],
        'post_author'      => $remote_post['author'],
        'comment_status'   => $remote_post['comment_status'],
        'ping_status'      => $remote_post['ping_status'],
        'post_date'        => $remote_post['date'],
        'post_date_gmt'    => $remote_post['date_gmt'],
        'post_modified'    => $remote_post['modified'],
        'post_modified_gmt'=> $remote_post['modified_gmt'],
    ];

    if ($existing) {
        $postarr['ID'] = $existing->ID;
        $post_id = wp_update_post($postarr);
    } else {
        $post_id = wp_insert_post($postarr);
    }

    if (is_wp_error($post_id)) continue;

    if (!empty($remote_post['categories'])) {
        wp_set_post_categories($post_id, $remote_post['categories']);
    }

    if (!empty($remote_post['tags'])) {
        wp_set_post_tags($post_id, $remote_post['tags']);
    }


    if (!empty($remote_post['featured_media'])) {
        set_post_thumbnail($post_id, $remote_post['featured_media']);
    }

 
    if (!empty($remote_post['format'])) {
        set_post_format($post_id, $remote_post['format']);
    }

  
    if (!empty($remote_post['template'])) {
        update_post_meta($post_id, '_wp_page_template', $remote_post['template']);
    }


    if (!empty($remote_post['sticky'])) {
        stick_post($post_id);
    } else {
        unstick_post($post_id);
    }


    if (!empty($remote_post['meta'])) {
        foreach ($remote_post['meta'] as $key => $value) {
            update_post_meta($post_id, $key, $value);
        }
    }
}


        return [
    'received' => count($senderPosts),
    'posts'    => $all_posts
];
    }
}else{
      return new WP_REST_Response(['error' => 'Invalid type parameter'], 400);
}
    if($body->custom_type === 'category' ) {    // && term_exists( $body->type, 'category')
    if($body->custom_type === 'category') {
        $args = array(
            'post_type' => 'any',
            'post_status' => 'publish',
            'posts_per_page' => -1, 
            'fields' => 'all', 
            'category_name'  => $body->type,   
        );
        
        $query = new WP_Query($args);
        $all_posts = array();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                global $post;
                $post_data = array(
                    'id' => $post->ID,
                    'date' => $post->post_date,
                    'date_gmt' => $post->post_date_gmt,
                    'modified' => $post->post_modified,
                    'modified_gmt' => $post->post_modified_gmt,
                    'slug' => $post->post_name,
                    'status' => $post->post_status,
                    'type' => $post->post_type,
                    'link' => get_permalink($post->ID),
                    'title' => array(
                        'rendered' => get_the_title($post->ID)
                    ),
                    'content' => array(
                        'rendered' => get_the_content(null, false, $post->ID),
                        'protected' => false
                    ),
                    'excerpt' => array(
                        'rendered' => get_the_excerpt($post->ID),
                        'protected' => false
                    ),
                    'author' => (int) $post->post_author,
                    'featured_media' => (int) get_post_thumbnail_id($post->ID),
                    'comment_status' => $post->comment_status,
                    'ping_status' => $post->ping_status,
                    'sticky' => is_sticky($post->ID),
                    'template' => get_page_template_slug($post->ID),
                    'format' => get_post_format($post->ID) ?: 'standard',
                    'meta' => array(),
                    'categories' => wp_get_post_categories($post->ID, array('fields' => 'ids')),
                    'tags' => wp_get_post_tags($post->ID, array('fields' => 'ids')),
                );
                
                $all_posts[] = $post_data;
            }
            wp_reset_postdata();
        } 
        $senderPosts = $body->myallpostsItems;
        $senderPosts = json_decode(json_encode($senderPosts), true);

        // $resultArray = array_merge($senderPosts , $all_posts);
        // $uniquePosts =  array_unique($resultArray);
        //   wp_insert_post( $uniquePosts,$wp_error = false );
foreach ($senderPosts as $remote_post) {

    $existing = get_page_by_path($remote_post['slug'], OBJECT, $remote_post['type']);

    $postarr = [
        'post_title'       => $remote_post['title']['rendered'],
        'post_name'        => $remote_post['slug'],
        'post_status'      => $remote_post['status'],
        'post_type'        => $remote_post['type'],
        'post_content'     => $remote_post['content']['rendered'],
        'post_excerpt'     => $remote_post['excerpt']['rendered'],
        'post_author'      => $remote_post['author'],
        'comment_status'   => $remote_post['comment_status'],
        'ping_status'      => $remote_post['ping_status'],
        'post_date'        => $remote_post['date'],
        'post_date_gmt'    => $remote_post['date_gmt'],
        'post_modified'    => $remote_post['modified'],
        'post_modified_gmt'=> $remote_post['modified_gmt'],
    ];

    if ($existing) {
        $postarr['ID'] = $existing->ID;
        $post_id = wp_update_post($postarr);
    } else {
        $post_id = wp_insert_post($postarr);
    }

    if (is_wp_error($post_id)) continue;

    if (!empty($remote_post['categories'])) {
        wp_set_post_categories($post_id, $remote_post['categories']);
    }

    if (!empty($remote_post['tags'])) {
        wp_set_post_tags($post_id, $remote_post['tags']);
    }


    if (!empty($remote_post['featured_media'])) {
        set_post_thumbnail($post_id, $remote_post['featured_media']);
    }

 
    if (!empty($remote_post['format'])) {
        set_post_format($post_id, $remote_post['format']);
    }

  
    if (!empty($remote_post['template'])) {
        update_post_meta($post_id, '_wp_page_template', $remote_post['template']);
    }


    if (!empty($remote_post['sticky'])) {
        stick_post($post_id);
    } else {
        unstick_post($post_id);
    }


    if (!empty($remote_post['meta'])) {
        foreach ($remote_post['meta'] as $key => $value) {
            update_post_meta($post_id, $key, $value);
        }
    }
}


        return [
    'received' => count($senderPosts),
    'posts'    => $all_posts
];
    }
}else{
      return new WP_REST_Response(['error' => 'Invalid type parameter'], 400);
}    
    return new WP_REST_Response(['error' => 'Invalid type parameter'], 400);
}
function do_api_action_pages($body){
    if(!isset($body->key) || $body->key !== $this->key){
        return new WP_REST_Response(['error' => 'Invalid key'], 403);
    }
    
    if($body->type === 'page') {
        $args = array(
            'post_type' => 'page',
            'post_status' => 'publish',
            'posts_per_page' => -1, 
            'fields' => 'all', 
        );
        
        $query = new WP_Query($args);
        $all_posts = array();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                global $post;
                $post_data = array(
                    'id' => $post->ID,
                    'date' => $post->post_date,
                    'date_gmt' => $post->post_date_gmt,
                    'modified' => $post->post_modified,
                    'modified_gmt' => $post->post_modified_gmt,
                    'slug' => $post->post_name,
                    'status' => $post->post_status,
                    'type' => $post->post_type,
                    'link' => get_permalink($post->ID),
                    'title' => array(
                        'rendered' => get_the_title($post->ID)
                    ),
                    'content' => array(
                        'rendered' => get_the_content(null, false, $post->ID),
                        'protected' => false
                    ),
                    'excerpt' => array(
                        'rendered' => get_the_excerpt($post->ID),
                        'protected' => false
                    ),
                    'author' => (int) $post->post_author,
                    'featured_media' => (int) get_post_thumbnail_id($post->ID),
                    'comment_status' => $post->comment_status,
                    'ping_status' => $post->ping_status,
                    'sticky' => is_sticky($post->ID),
                    'template' => get_page_template_slug($post->ID),
                    'format' => get_post_format($post->ID) ?: 'standard',
                    'meta' => array(),
                    'categories' => wp_get_post_categories($post->ID, array('fields' => 'ids')),
                    'tags' => wp_get_post_tags($post->ID, array('fields' => 'ids')),
                );
                
                $all_posts[] = $post_data;
            }
            wp_reset_postdata();
        } 
        $senderPosts = $body->myallpostsItems;
        $senderPosts = json_decode(json_encode($senderPosts), true);

foreach ($senderPosts as $remote_post) {

    $existing = get_page_by_path($remote_post['slug'], OBJECT, $remote_post['type']);

    $postarr = [
        'post_title'       => $remote_post['title']['rendered'],
        'post_name'        => $remote_post['slug'],
        'post_status'      => $remote_post['status'],
        'post_type'        => $remote_post['type'],
        'post_content'     => $remote_post['content']['rendered'],
        'post_excerpt'     => $remote_post['excerpt']['rendered'],
        'post_author'      => $remote_post['author'],
        'comment_status'   => $remote_post['comment_status'],
        'ping_status'      => $remote_post['ping_status'],
        'post_date'        => $remote_post['date'],
        'post_date_gmt'    => $remote_post['date_gmt'],
        'post_modified'    => $remote_post['modified'],
        'post_modified_gmt'=> $remote_post['modified_gmt'],
    ];

    if ($existing) {
        $postarr['ID'] = $existing->ID;
        $post_id = wp_update_post($postarr);
    } else {
        $post_id = wp_insert_post($postarr);
    }

    if (is_wp_error($post_id)) continue;

    if (!empty($remote_post['categories'])) {
        wp_set_post_categories($post_id, $remote_post['categories']);
    }

    if (!empty($remote_post['tags'])) {
        wp_set_post_tags($post_id, $remote_post['tags']);
    }


    if (!empty($remote_post['featured_media'])) {
        set_post_thumbnail($post_id, $remote_post['featured_media']);
    }

 
    if (!empty($remote_post['format'])) {
        set_post_format($post_id, $remote_post['format']);
    }

  
    if (!empty($remote_post['template'])) {
        update_post_meta($post_id, '_wp_page_template', $remote_post['template']);
    }


    if (!empty($remote_post['sticky'])) {
        stick_post($post_id);
    } else {
        unstick_post($post_id);
    }


    if (!empty($remote_post['meta'])) {
        foreach ($remote_post['meta'] as $key => $value) {
            update_post_meta($post_id, $key, $value);
        }
    }
}


        return [
    'received' => count($senderPosts),
    'posts'    => $all_posts
];
    }
    
    return new WP_REST_Response(['error' => 'Invalid type parameter'], 400);
}
function do_api_action_posts($body){
    if(!isset($body->key) || $body->key !== $this->key){
        return new WP_REST_Response(['error' => 'Invalid key'], 403);
    }
    
    if($body->type === 'post') {
        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => -1, 
            'fields' => 'all', 
        );
        
        $query = new WP_Query($args);
        $all_posts = array();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                global $post;
                $post_data = array(
                    'id' => $post->ID,
                    'date' => $post->post_date,
                    'date_gmt' => $post->post_date_gmt,
                    'modified' => $post->post_modified,
                    'modified_gmt' => $post->post_modified_gmt,
                    'slug' => $post->post_name,
                    'status' => $post->post_status,
                    'type' => $post->post_type,
                    'link' => get_permalink($post->ID),
                    'title' => array(
                        'rendered' => get_the_title($post->ID)
                    ),
                    'content' => array(
                        'rendered' => get_the_content(null, false, $post->ID),
                        'protected' => false
                    ),
                    'excerpt' => array(
                        'rendered' => get_the_excerpt($post->ID),
                        'protected' => false
                    ),
                    'author' => (int) $post->post_author,
                    'featured_media' => (int) get_post_thumbnail_id($post->ID),
                    'comment_status' => $post->comment_status,
                    'ping_status' => $post->ping_status,
                    'sticky' => is_sticky($post->ID),
                    'template' => get_page_template_slug($post->ID),
                    'format' => get_post_format($post->ID) ?: 'standard',
                    'meta' => array(),
                    'categories' => wp_get_post_categories($post->ID, array('fields' => 'ids')),
                    'tags' => wp_get_post_tags($post->ID, array('fields' => 'ids')),
                );
                
                $all_posts[] = $post_data;
            }
            wp_reset_postdata();
        } 
        $senderPosts = $body->myallpostsItems;
        $senderPosts = json_decode(json_encode($senderPosts), true);

        // $resultArray = array_merge($senderPosts , $all_posts);
        // $uniquePosts =  array_unique($resultArray);
        //   wp_insert_post( $uniquePosts,$wp_error = false );
foreach ($senderPosts as $remote_post) {

    $existing = get_page_by_path($remote_post['slug'], OBJECT, $remote_post['type']);

    $postarr = [
        'post_title'       => $remote_post['title']['rendered'],
        'post_name'        => $remote_post['slug'],
        'post_status'      => $remote_post['status'],
        'post_type'        => $remote_post['type'],
        'post_content'     => $remote_post['content']['rendered'],
        'post_excerpt'     => $remote_post['excerpt']['rendered'],
        'post_author'      => $remote_post['author'],
        'comment_status'   => $remote_post['comment_status'],
        'ping_status'      => $remote_post['ping_status'],
        'post_date'        => $remote_post['date'],
        'post_date_gmt'    => $remote_post['date_gmt'],
        'post_modified'    => $remote_post['modified'],
        'post_modified_gmt'=> $remote_post['modified_gmt'],
    ];

    if ($existing) {
        $postarr['ID'] = $existing->ID;
        $post_id = wp_update_post($postarr);
    } else {
        $post_id = wp_insert_post($postarr);
    }

    if (is_wp_error($post_id)) continue;

    if (!empty($remote_post['categories'])) {
        wp_set_post_categories($post_id, $remote_post['categories']);
    }

    if (!empty($remote_post['tags'])) {
        wp_set_post_tags($post_id, $remote_post['tags']);
    }


    if (!empty($remote_post['featured_media'])) {
        set_post_thumbnail($post_id, $remote_post['featured_media']);
    }

 
    if (!empty($remote_post['format'])) {
        set_post_format($post_id, $remote_post['format']);
    }

  
    if (!empty($remote_post['template'])) {
        update_post_meta($post_id, '_wp_page_template', $remote_post['template']);
    }


    if (!empty($remote_post['sticky'])) {
        stick_post($post_id);
    } else {
        unstick_post($post_id);
    }


    if (!empty($remote_post['meta'])) {
        foreach ($remote_post['meta'] as $key => $value) {
            update_post_meta($post_id, $key, $value);
        }
    }
}


        return [
    'received' => count($senderPosts),
    'posts'    => $all_posts
];
    }
    
    return new WP_REST_Response(['error' => 'Invalid type parameter'], 400);
}
function do_api_action($body){
    if(!isset($body->key) || $body->key !== $this->key){
        return new WP_REST_Response(['error' => 'Invalid key'], 403);
    }
    
    if($body->type === 'all') {
        $args = array(
            'post_type' => 'any',
            'post_status' => 'publish',
            'posts_per_page' => -1, 
            'fields' => 'all', 
        );
        
        $query = new WP_Query($args);
        $all_posts = array();
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                global $post;
                $post_data = array(
                    'id' => $post->ID,
                    'date' => $post->post_date,
                    'date_gmt' => $post->post_date_gmt,
                    'modified' => $post->post_modified,
                    'modified_gmt' => $post->post_modified_gmt,
                    'slug' => $post->post_name,
                    'status' => $post->post_status,
                    'type' => $post->post_type,
                    'link' => get_permalink($post->ID),
                    'title' => array(
                        'rendered' => get_the_title($post->ID)
                    ),
                    'content' => array(
                        'rendered' => get_the_content(null, false, $post->ID),
                        'protected' => false
                    ),
                    'excerpt' => array(
                        'rendered' => get_the_excerpt($post->ID),
                        'protected' => false
                    ),
                    'author' => (int) $post->post_author,
                    'featured_media' => (int) get_post_thumbnail_id($post->ID),
                    'comment_status' => $post->comment_status,
                    'ping_status' => $post->ping_status,
                    'sticky' => is_sticky($post->ID),
                    'template' => get_page_template_slug($post->ID),
                    'format' => get_post_format($post->ID) ?: 'standard',
                    'meta' => array(),
                    'categories' => wp_get_post_categories($post->ID, array('fields' => 'ids')),
                    'tags' => wp_get_post_tags($post->ID, array('fields' => 'ids')),
                );
                
                $all_posts[] = $post_data;
            }
            wp_reset_postdata();
        } 
        $senderPosts = $body->myallpostsItems;
        $senderPosts = json_decode(json_encode($senderPosts), true);

        // $resultArray = array_merge($senderPosts , $all_posts);
        // $uniquePosts =  array_unique($resultArray);
        //   wp_insert_post( $uniquePosts,$wp_error = false );
foreach ($senderPosts as $remote_post) {

    $existing = get_page_by_path($remote_post['slug'], OBJECT, $remote_post['type']);

    $postarr = [
        'post_title'       => $remote_post['title']['rendered'],
        'post_name'        => $remote_post['slug'],
        'post_status'      => $remote_post['status'],
        'post_type'        => $remote_post['type'],
        'post_content'     => $remote_post['content']['rendered'],
        'post_excerpt'     => $remote_post['excerpt']['rendered'],
        'post_author'      => $remote_post['author'],
        'comment_status'   => $remote_post['comment_status'],
        'ping_status'      => $remote_post['ping_status'],
        'post_date'        => $remote_post['date'],
        'post_date_gmt'    => $remote_post['date_gmt'],
        'post_modified'    => $remote_post['modified'],
        'post_modified_gmt'=> $remote_post['modified_gmt'],
    ];

    if ($existing) {
        $postarr['ID'] = $existing->ID;
        $post_id = wp_update_post($postarr);
    } else {
        $post_id = wp_insert_post($postarr);
    }

    if (is_wp_error($post_id)) continue;

    if (!empty($remote_post['categories'])) {
        wp_set_post_categories($post_id, $remote_post['categories']);
    }

    if (!empty($remote_post['tags'])) {
        wp_set_post_tags($post_id, $remote_post['tags']);
    }


    if (!empty($remote_post['featured_media'])) {
        set_post_thumbnail($post_id, $remote_post['featured_media']);
    }

 
    if (!empty($remote_post['format'])) {
        set_post_format($post_id, $remote_post['format']);
    }

  
    if (!empty($remote_post['template'])) {
        update_post_meta($post_id, '_wp_page_template', $remote_post['template']);
    }


    if (!empty($remote_post['sticky'])) {
        stick_post($post_id);
    } else {
        unstick_post($post_id);
    }


    if (!empty($remote_post['meta'])) {
        foreach ($remote_post['meta'] as $key => $value) {
            update_post_meta($post_id, $key, $value);
        }
    }
}


        return [
    'received' => count($senderPosts),
    'posts'    => $all_posts
];
    }
    
    return new WP_REST_Response(['error' => 'Invalid type parameter'], 400);
}

function getMyPosts(){
    $args = array(
        'post_type' => 'any',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'fields' => 'all',
    );
    
    $query = new WP_Query($args);
    $all_posts = array();
    
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            global $post;

           $post_data = [
    'id' => $post->ID,
    'date' => $post->post_date,
    'date_gmt' => $post->post_date_gmt,
    'modified' => $post->post_modified,
    'modified_gmt' => $post->post_modified_gmt,
    'slug' => $post->post_name,
    'status' => $post->post_status,
    'type' => $post->post_type,
    'link' => get_permalink($post->ID),
    'title' => ['rendered' => get_the_title($post->ID)],
    'content' => ['rendered' => get_the_content(), 'protected' => false],
    'excerpt' => ['rendered' => get_the_excerpt(), 'protected' => false],
    'author' => (int) $post->post_author,
    'featured_media' => (int) get_post_thumbnail_id($post->ID),
    'comment_status' => $post->comment_status,
    'ping_status' => $post->ping_status,
    'sticky' => is_sticky($post->ID),
    'template' => get_page_template_slug($post->ID),
    'format' => get_post_format($post->ID) ?: 'standard',
    'meta' => array_filter(
        get_post_meta($post->ID),
        fn($key) => !str_starts_with($key, '_'),
        ARRAY_FILTER_USE_KEY
    ),
    'categories' => wp_get_post_categories($post->ID, ['fields' => 'ids']),
    'tags' => wp_get_post_tags($post->ID, ['fields' => 'ids']),

    'taxonomies' => [],
];
    $taxonomies = get_object_taxonomies($post->post_type, 'objects');

    foreach ($taxonomies as $taxonomy => $tax_obj) {
        if (in_array($taxonomy, ['category', 'post_tag'])) continue; // already handled
        
        $terms = wp_get_post_terms($post->ID, $taxonomy, ['fields' => 'ids']);
        $post_data['taxonomies'][$taxonomy] = $terms ?: [];
    }

            $all_posts[] = $post_data;
        }
        wp_reset_postdata();
    }

    return $all_posts;
}

function do_api_action_set_data($body){
        if($body->key !== $this->key){
         return 404;
    }
        elseif($body->type === 'post') {

        $postarr = [
            'post_title'   => sanitize_text_field($body->data->title),
            'post_content' => wp_kses_post($body->data->content),
            'post_status'  => 'publish',
            'post_type'    => 'post'
        ];

        $post_id = wp_insert_post($postarr);

        if (is_wp_error($post_id)) {
            return new WP_REST_Response(['error' => 'Failed to create post'], 500);
        }

        return ['success' => true, 'post_id' => $post_id];
    }
}

function plugin_admin_menu(){
   add_menu_page(
    'WP Sync Rest Page',
    'WP Sync Rest',
    'manage_options',
    'wp-sync-rest',
    [$this, 'plugin_content'],
    'dashicons-controls-repeat',
    10
   );
   add_submenu_page(
    'wp-sync-rest',
    'Sync',
    'Sync',
    'manage_options',
    'plugin_sync',
    [$this,'sync_page'],
   );
}
function sync_page(){
       ?>
    <nav >
 <h1>WP Sync Data</h1>
 <p></p> 
    </nav>
    <div id="syncing"  class="dx-none">Syncing in Process...</div>
    <div class="settings">
        <p class="settingsHeading">Settings</p>
      
            <ul class="settingsMenu">
                <li>
                    <select name="selectPostType" id="selectPostType">
                        <option default value="all">All Posts</option>
                    <?php
                    $post_types = get_post_types(['public' => true], 'objects');
                
                    foreach ($post_types as $post_type) {
                        echo '<option value="' . esc_attr($post_type->name) . '">'
                            . $post_type->labels->singular_name
                            . '</option>';
                    }
                        ?>
                    </select>
                </li>
                <li>
                    <select name="selectCategory" id="selectCategory">
                        <option value="all">All Categories</option>

                        <?php
                        $categories = get_terms([
                            'taxonomy'   => 'category',
                            'hide_empty' => false,
                        ]);
                    
                        foreach ($categories as $cat) {
                            echo '<option value="' . $cat->term_id . '">'
                                . $cat->name .
                            '</option>';
                        }
                        ?>
                    </select>
                </li>
                <li>
                     <select name="selectTaxonomy" id="selectTaxonomy">
                         <option value="all">All Taxonomies</option>
                         <?php
                         $taxonomies = get_taxonomies(['public' => true], 'objects');
                         foreach ($taxonomies as $tax) {
                             if (in_array($tax->name, ['category', 'post_tag'])) continue;
                             echo '<option value="' . esc_attr($tax->name) . '">' . $tax->labels->singular_name . '</option>';
                         }
                         ?>
                      </select>
                </li>

                <li><input type="number" name="paginationSize" id="size" placeholder="Pagination Size"></li>
            </ul>
       <button type="button" id="applySettings">APPLY</button>
    </div>
    <main class="settingsMain">
       <div class="selectedSites"><div id="heading" >
        <p>Available Sites</p> 
        <div id="emptyHeading" class="hide">Empty</div>
        <button id="clear" type="button" style="display: none;" >Clear Sites</button></div>
        <ul id="urls"></ul>
        <button type="button" id="sync_Page_Enter" class="hide">SYNC</button>
       </div>
    </main>
     </div>
    </div>
    <?php
}

function plugin_content(){
    ?>
    <nav >
 <h1>WP Sync Data</h1>
 <p></p> 
    </nav>
    <div class="main">
     <section>
        <div id="syncing"  class="dx-none">Syncing in Process...</div>
        <form action="" id="sync_form">
            <div class="inputs">
            <label for="api_key">API Key</label>
            <input type="text" name="api_key" id="api_key" required placeholder="Enter Api Key..">
            <label for="Url" class="urlLabel">URLs</label>
            <input type="url" name="url" id="url" required placeholder="Enter urls">
            </div>
            <div class="empty_err">
            <p id="empty_url" class="hide">Please enter urls</p>
            <p id="empty_key" class="hide">Please enter key</p>
            </div>
            <button type="button" id="enterSite">ENTER SITE</button>
            <div id="emptySitesErr" class="hide">Please enter a site</div>
            <div class="selectedSites"><div id="heading" class="hide"><p>Selected Sites</p> <button id="clear" type="button" style="display: none;">Clear Sites</button></div><ul id="urls"></ul></div>
            <div class="buttons" style="display: none;"> 
            <button type="button" id="sync_posts">Sync Posts</button>
             <button type="button"  id="sync_pages">Sync Pages</button>
             <button  type="button" id="sync_all">Sync All</button>
             </div>
        </form>
        <div id="your_key">Show my key</div>
        <div class="customQuery" style="display: none;">
            <p>Customized Sync</p>
            <div class="query">
                <input type="text" name="post_type" id="postTypeInp" placeholder="Enter the Post Type">
                <button type="button" id ="customPostSync">Sync</button>
            </div>
            <div class="query">
                <input type="text" name="category" id="categoryInp" placeholder="Enter the Category">
                <button type="button" id="catSync">Sync</button>
            </div>
        </div>
     </section>
     <div>
     </div>
    </div>
    <?php
}
}


new sync();


